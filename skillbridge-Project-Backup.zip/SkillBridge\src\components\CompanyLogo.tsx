interface CompanyLogoProps {
  id: string;
  name: string;
  className?: string;
  size?: "sm" | "md" | "lg";
}

export default function CompanyLogo({
  id,
  name,
  className = "",
  size = "md",
}: CompanyLogoProps) {
  const containerSize =
    size === "sm"
      ? "w-8 h-8 rounded-lg p-1.5"
      : size === "lg"
      ? "w-14 h-14 rounded-2xl p-2.5"
      : "w-10 h-10 rounded-xl p-2";

  const renderLogoSvg = () => {
    switch (id.toLowerCase()) {
      case "nvidia":
        return (
          // Official NVIDIA Green Claw / Spiral Logo
          <svg viewBox="0 0 100 100" className="w-full h-full" fill="none">
            <path
              d="M50 12C28.5 12 12 28.5 12 50c0 21.5 16.5 38 38 38 18.5 0 33.5-12.5 37.2-29.2h-11C72.7 70.3 62.3 78 50 78c-15.5 0-28-12.5-28-28s12.5-28 28-28c11 0 20.3 6.3 24.8 15.5h11C81.5 24 67.2 12 50 12z"
              fill="#76B900"
            />
            <path
              d="M50 28c-12.2 0-22 9.8-22 22s9.8 22 22 22c8.8 0 16.3-5.2 19.8-12.8h-9.2C58 53.6 54.3 56 50 56c-3.3 0-6-2.7-6-6s2.7-6 6-6c4.3 0 8 2.4 10.6 6.8h9.2C66.3 33.2 58.8 28 50 28z"
              fill="#76B900"
            />
            <circle cx="50" cy="50" r="4.5" fill="#76B900" />
          </svg>
        );

      case "google":
        return (
          // Official Google 4-Color 'G' Logo
          <svg viewBox="0 0 48 48" className="w-full h-full">
            <path
              fill="#EA4335"
              d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
            />
            <path
              fill="#4285F4"
              d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
            />
            <path
              fill="#FBBC05"
              d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
            />
            <path
              fill="#34A853"
              d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
            />
          </svg>
        );

      case "microsoft":
        return (
          // Official Microsoft 4-Quadrant Logo
          <svg viewBox="0 0 48 48" className="w-full h-full">
            <rect x="2" y="2" width="20" height="20" fill="#F25022" rx="1.5" />
            <rect x="26" y="2" width="20" height="20" fill="#7FBA00" rx="1.5" />
            <rect x="2" y="26" width="20" height="20" fill="#00A4EF" rx="1.5" />
            <rect x="26" y="26" width="20" height="20" fill="#FFB900" rx="1.5" />
          </svg>
        );

      case "amazon":
        return (
          // Official Amazon 'a' with Smile Arrow
          <svg viewBox="0 0 54 48" className="w-full h-full">
            <path
              fill="#232F3E"
              className="dark:fill-slate-100"
              d="M27.5 13.8c-7.2 0-12.8 5.6-12.8 12.8 0 4.2 2 8 5.1 10.4-1.2.6-2.5 1.1-4 1.5l1.6 3.8c4.6-1.2 8.4-3.5 11.2-6.5 6.2-.2 11.2-5.4 11.2-11.8 0-7.2-5.5-12.8-12.3-12.8zm-.1 21.2c-4.6 0-8.3-3.8-8.3-8.4s3.7-8.4 8.3-8.4 8.3 3.8 8.3 8.4-3.7 8.4-8.3 8.4z"
            />
            {/* The Amazon smile arrow */}
            <path
              d="M5 38c11 8 26 8 38 0"
              fill="none"
              stroke="#FF9900"
              strokeWidth="4"
              strokeLinecap="round"
            />
            <path
              d="M40 35l5 4-2-6"
              fill="#FF9900"
              stroke="#FF9900"
              strokeWidth="1.5"
              strokeLinejoin="round"
            />
          </svg>
        );

      case "qualcomm":
        return (
          // Official Qualcomm Q Emblem
          <svg viewBox="0 0 50 50" className="w-full h-full">
            <circle cx="25" cy="25" r="21" fill="none" stroke="#3253DC" strokeWidth="6" />
            <path
              d="M32 30l11 11"
              stroke="#3253DC"
              strokeWidth="6"
              strokeLinecap="round"
            />
            <circle cx="25" cy="25" r="8" fill="#3253DC" />
          </svg>
        );

      case "adobe":
        return (
          // Official Adobe 'A' Red Badge
          <svg viewBox="0 0 48 48" className="w-full h-full">
            <rect width="48" height="48" rx="10" fill="#FA0F00" />
            <path
              d="M29.5 8H38v32h-6.2l-4.5-10.8h-6.6l6-14.4h2.8zM18.5 8H10v32h6.2l7.2-17.2-4.9-14.8z"
              fill="#FFFFFF"
            />
          </svg>
        );

      case "intel":
        return (
          // Official Intel Logo
          <svg viewBox="0 0 60 40" className="w-full h-full">
            <circle cx="10" cy="11" r="3.2" fill="#0071C5" />
            <path
              fill="#0071C5"
              d="M7.5 17h5v18h-5zM17 17h5v2.8c1.3-2 3.8-3.2 6.5-3.2 5.5 0 8.5 3.5 8.5 9.4V35h-5v-8.2c0-3.2-1.4-4.8-4-4.8-2.6 0-4.5 1.8-5 4.5V35h-6V17zM42 9h5v8h5v4h-5v8.5c0 1.8.8 2.5 2.5 2.5H52v4c-1.5.3-3.2.4-4.8.4-4.5 0-6.7-2.2-6.7-6.5V21h-3.5v-4h3.5V9z"
            />
          </svg>
        );

      case "openai":
        return (
          // Official OpenAI Rosette / Vortex Mark
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <path
              fill="currentColor"
              className="text-slate-900 dark:text-slate-100"
              d="M87.6 42.8c-.8-6.1-4.7-11.2-10.3-13.8 1.1-6.1-.7-12.4-5.1-16.7-4.9-4.8-12-6.6-18.7-4.6C49.9 3.5 44.5 1.8 39 3c-6.1 1.3-11.2 5.5-13.8 11.1-6.1-1.1-12.4.7-16.7 5.1-4.8 4.9-6.6 12-4.6 18.7-4.2 3.6-5.9 9-4.7 14.5.8 6.1 4.7 11.2 10.3 13.8-1.1 6.1.7 12.4 5.1 16.7 4.9 4.8 12 6.6 18.7 4.6 3.6 4.2 9 5.9 14.5 4.7 6.1-1.3 11.2-5.5 13.8-11.1 6.1 1.1 12.4-.7 16.7-5.1 4.8-4.9 6.6-12 4.6-18.7 4.2-3.6 5.9-9 4.7-14.5zm-33.8 46c-2.4 0-4.8-.6-6.9-1.8l-15.6-9c-.7-.4-1.2-1.1-1.5-1.9s-.2-1.7.3-2.4c1.3-2.2 4-2.9 6.2-1.6l14.4 8.3c4.1 2.4 9.3 1 11.6-3.1 1.5-2.6 1.7-5.8.6-8.6l-2.2-5.7c-.5-1.3.1-2.7 1.4-3.2 1.3-.5 2.7.1 3.2 1.4l2.2 5.7c2 5.3 1.5 11.3-1.4 16.2-2.9 4-7.5 6.3-12.3 6.3z"
            />
            <path
              fill="currentColor"
              className="text-slate-900 dark:text-slate-100"
              d="M50 36c-7.7 0-14 6.3-14 14s6.3 14 14 14 14-6.3 14-14-6.3-14-14-14zm0 22c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8z"
            />
          </svg>
        );

      case "salesforce":
        return (
          // Official Salesforce Blue Cloud Logo
          <svg viewBox="0 0 54 38" className="w-full h-full">
            <path
              fill="#00A1E0"
              d="M22.8 4.2C25.4 1.6 29 0 33 0c6.6 0 12.1 4.6 13.6 10.8 2.2.7 4.1 2.2 5.3 4.2 1.4 2.3 2.1 5 2.1 7.8 0 8.4-6.8 15.2-15.2 15.2H12C5.4 38 0 32.6 0 26c0-5.8 4.2-10.7 9.8-11.7.9-5.7 5.7-10.1 11.6-10.1h1.4z"
            />
            <path
              fill="#FFFFFF"
              d="M19.2 18.5c-.8-.8-1.9-1.2-3.1-1.2-2.4 0-4.3 1.9-4.3 4.3 0 2.4 1.9 4.3 4.3 4.3 1.2 0 2.3-.4 3.1-1.2l-1.1-1.1c-.5.5-1.2.8-2 .8-1.5 0-2.8-1.2-2.8-2.8s1.2-2.8 2.8-2.8c.8 0 1.5.3 2 .8l1.1-1.1zM28.4 17.5h-5.2v8.4h5.2v-1.6h-3.4v-2h3.1v-1.5h-3.1v-1.7h3.4v-1.6zM34.8 21.2c0-2.2-1.7-3.9-3.9-3.9-2.2 0-3.9 1.7-3.9 3.9s1.7 3.9 3.9 3.9c2.2 0 3.9-1.7 3.9-3.9zm-1.8 0c0 1.3-1 2.3-2.1 2.3s-2.1-1-2.1-2.3 1-2.3 2.1-2.3 2.1 1 2.1 2.3z"
            />
          </svg>
        );

      case "cisco":
        return (
          // Official Cisco Bar Waves Logo
          <svg viewBox="0 0 54 36" className="w-full h-full">
            <g fill="#049FD9">
              <rect x="3" y="16" width="3.5" height="12" rx="1.7" />
              <rect x="9.5" y="10" width="3.5" height="18" rx="1.7" />
              <rect x="16" y="4" width="3.5" height="24" rx="1.7" />
              <rect x="22.5" y="10" width="3.5" height="18" rx="1.7" />
              <rect x="29" y="16" width="3.5" height="12" rx="1.7" />
              <rect x="35.5" y="10" width="3.5" height="18" rx="1.7" />
              <rect x="42" y="4" width="3.5" height="24" rx="1.7" />
              <rect x="48.5" y="10" width="3.5" height="18" rx="1.7" />
            </g>
          </svg>
        );

      default:
        return (
          <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
            {name[0]}
          </span>
        );
    }
  };

  return (
    <div
      className={`bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center shrink-0 shadow-xs ${containerSize} ${className}`}
      title={`${name} Official Logo`}
      aria-label={`${name} Logo`}
    >
      <div className="w-full h-full flex items-center justify-center object-contain">
        {renderLogoSvg()}
      </div>
    </div>
  );
}
