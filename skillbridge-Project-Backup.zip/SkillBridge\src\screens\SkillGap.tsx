import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { CAREERS, RESOURCES } from "../lib/catalog";
import { hoursToClose } from "../lib/roadmap";
import { useStore } from "../lib/store";

const sevColor = { high: "#F43F5E", medium: "#F59E0B", low: "#10B981", met: "#10B981" };
const sevLabel = { high: "High", medium: "Medium", low: "Low", met: "Met" };
const statusText: Record<string, string> = { self: "Self-reported", assessed: "Assessed", verified: "Verified" };

export default function SkillGap() {
  const { state, patch, career, rows, counts, readiness } = useStore();
  const gaps = rows.filter((r) => r.gap > 0);
  const missing = rows.filter((r) => r.missing);
  const chartData = rows.map((r) => ({ skill: r.name, current: r.current, gap: r.gap, required: r.target }));
  const perWeek = Math.max(1, state.position.weeklyHours);
  const totalHours = gaps.reduce((s, g) => s + hoursToClose(g.gap), 0);
  const priorities = gaps.slice(0, 3);

  return (
    <div className="p-5 max-w-6xl mx-auto">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-semibold text-slate-800">Skill Gap Analysis</h1>
            <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-medium">Calculated from your ratings</span>
          </div>
          <p className="text-sm text-slate-500">
            Your skills vs SkillBridge's expected proficiency for <strong className="text-slate-700">{career?.title}</strong>. Targets are learning estimates, not employer requirements.
          </p>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 mb-1 block">Target career</label>
          <select value={state.careerId ?? ""} onChange={(e) => patch({ careerId: e.target.value })}
            className="text-sm border border-slate-200 rounded-xl px-3 py-2 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300">
            {CAREERS.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </select>
        </div>
      </div>

      {/* Summary */}
      <div className="bg-gradient-to-r from-indigo-50 to-violet-50 border border-indigo-100 rounded-2xl p-5 mb-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-indigo-600">Overall Gap Score</p>
            <p className="text-4xl font-bold mt-1 font-mono text-slate-800">{gaps.length} gaps</p>
            <p className="text-sm text-slate-500 mt-1">
              Readiness estimate {readiness ?? 0}% · ~{totalHours} study hours ≈ {Math.ceil(totalHours / perWeek)} weeks at {perWeek} h/week
            </p>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: "High Priority", value: counts.high, color: "text-rose-600" },
              { label: "Medium", value: counts.medium, color: "text-amber-600" },
              { label: "Low", value: counts.low, color: "text-emerald-600" },
            ].map((s) => (
              <div key={s.label} className="text-center">
                <p className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</p>
                <p className="text-xs text-slate-500 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
        <p className="text-[11px] text-slate-400 mt-3">Priority rule: High = gap of 40+ points, Medium = 20–39, Low = 1–19. Readiness is an estimate, not a hiring probability.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        {/* Gap chart */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-medium text-slate-700 mb-4">Gap by Skill (Current vs Expected)</p>
          <ResponsiveContainer width="100%" height={Math.max(240, rows.length * 32)}>
            <BarChart data={chartData} layout="vertical" margin={{ top: 0, right: 16, bottom: 0, left: 64 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: "#94A3B8" }} />
              <YAxis type="category" dataKey="skill" tick={{ fontSize: 11, fill: "#64748B" }} width={110} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} formatter={(v, name) => [`${v}%`, name]} />
              <Bar dataKey="current" name="Current" stackId="a" radius={0} fill="#4F46E5" fillOpacity={0.9} />
              <Bar dataKey="gap" name="Gap" stackId="a" radius={[0, 4, 4, 0]} fill="#EEF2FF" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Gap breakdown */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-medium text-slate-700 mb-4">Gap Breakdown</p>
          <div className="space-y-2">
            {rows.map((d) => (
              <div key={d.name} className="flex items-center gap-3 py-2 border-b border-slate-100 last:border-0">
                <div className="w-28 text-xs font-medium text-slate-700">
                  {d.name}
                  <p className="text-[10px] font-normal text-slate-400">{d.status ? statusText[d.status] : "Not listed"}</p>
                </div>
                <div className="flex-1">
                  <div className="flex gap-1 h-3 rounded-full overflow-hidden bg-slate-200 dark:bg-slate-700 shadow-2xs">
                    <div
                      className="h-full rounded-l-full transition-all"
                      style={{
                        width: `${d.current}%`,
                        background: d.current >= 80
                          ? "linear-gradient(90deg, #10B981 0%, #059669 100%)"
                          : d.current >= 50
                          ? "linear-gradient(90deg, #3B82F6 0%, #4F46E5 100%)"
                          : "linear-gradient(90deg, #F59E0B 0%, #D97706 100%)",
                      }}
                    />
                    <div
                      className="h-full bg-rose-200 dark:bg-rose-900/60 rounded-r-full"
                      style={{ width: `${d.gap}%` }}
                    />
                  </div>
                </div>
                <div className="text-right w-20">
                  <span className="text-[11px] font-mono font-semibold" style={{ color: sevColor[d.severity] }}>
                    {d.gap > 0 ? `-${d.gap}` : "✓"} <span className="font-normal text-slate-400">/ {d.target}</span>
                  </span>
                  <p className="text-[10px] text-slate-400">{sevLabel[d.severity]}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="flex gap-3 mt-3">
            <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-sm bg-indigo-500" /><span className="text-[11px] text-slate-500">Current</span></div>
            <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-sm bg-rose-200" /><span className="text-[11px] text-slate-500">Gap to expected</span></div>
          </div>
        </div>
      </div>

      {missing.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 mb-4">
          <p className="text-sm font-medium text-slate-700 mb-2">Missing skills <span className="text-[11px] font-normal text-slate-400">required for this role but not on your profile</span></p>
          <div className="flex flex-wrap gap-2">
            {missing.map((m) => <span key={m.name} className="text-[11px] bg-rose-50 text-rose-700 px-2 py-1 rounded-lg">{m.name} · expected {m.target}%</span>)}
          </div>
        </div>
      )}

      {/* Learning priorities */}
      <div>
        <p className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
          <span>Recommended Learning Priorities</span>
          <span className="text-[10px] font-normal text-slate-400">Ranked by gap size × skill weight</span>
        </p>
        <div className="space-y-3">
          {priorities.length === 0 && <div className="bg-white rounded-2xl border border-slate-200 p-5 text-sm text-slate-500">No gaps to prioritise: you meet every expected proficiency for this role.</div>}
          {priorities.map((g, i) => (
            <div key={g.name} className="bg-white rounded-2xl border border-slate-200 p-5">
              <div className="flex items-start gap-3">
                <div className={`mt-0.5 w-2 h-2 rounded-full shrink-0 ${g.severity === "high" ? "bg-rose-500" : g.severity === "medium" ? "bg-amber-400" : "bg-emerald-400"}`} />
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <p className="text-sm font-semibold text-slate-800">Priority {i + 1}: {g.name}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${g.severity === "high" ? "bg-rose-100 text-rose-700" : g.severity === "medium" ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"}`}>{sevLabel[g.severity]} Priority</span>
                    <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full">~{hoursToClose(g.gap)} h · {Math.max(1, Math.ceil(hoursToClose(g.gap) / perWeek))} wk</span>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed mb-3">
                    You are at {g.current}% and {career?.title} expects about {g.target}%, a gap of {g.gap} points.{g.missing ? " This skill is not on your profile yet." : ""}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {RESOURCES[g.name] ? (
                      <a href={RESOURCES[g.name].url} target="_blank" rel="noopener noreferrer" className="text-[11px] bg-slate-100 text-slate-600 px-2 py-1 rounded-lg hover:bg-indigo-50 hover:text-indigo-700">📚 {RESOURCES[g.name].title} ↗</a>
                    ) : (
                      <span className="text-[11px] bg-slate-100 text-slate-500 px-2 py-1 rounded-lg">📚 Use official documentation or a structured course for {g.name}</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
