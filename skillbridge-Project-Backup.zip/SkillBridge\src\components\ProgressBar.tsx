import { getProgressTier } from "../lib/progressColors";

interface ProgressBarProps {
  value: number; // 0 to 100
  max?: number;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
  className?: string;
}

export default function ProgressBar({
  value,
  max = 100,
  size = "md",
  showLabel = false,
  className = "",
}: ProgressBarProps) {
  const pct = Math.min(100, Math.max(0, Math.round((value / max) * 100)));
  const tier = getProgressTier(pct);

  const heightClass = size === "sm" ? "h-1.5" : size === "lg" ? "h-3" : "h-2";

  return (
    <div className={`w-full ${className}`}>
      {showLabel && (
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="font-semibold text-slate-700 dark:text-slate-200">
            {tier.label}
          </span>
          <span className="font-mono font-bold text-slate-600 dark:text-slate-300">
            {pct}%
          </span>
        </div>
      )}
      {/* Background track: dark high-contrast slate in light and dark mode */}
      <div
        className={`w-full rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden ${heightClass}`}
        role="progressbar"
        aria-valuenow={pct}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`Progress: ${pct}% (${tier.label})`}
      >
        <div
          className={`h-full rounded-full transition-all duration-500 ease-out shadow-xs ${tier.gradientClass}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
