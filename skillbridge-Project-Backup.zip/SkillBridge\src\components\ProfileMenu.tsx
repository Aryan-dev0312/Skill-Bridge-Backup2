import { useState, useEffect, useRef } from "react";
import { useStore } from "../lib/store";
import { getStoredTheme, applyTheme, type ThemeMode } from "../lib/theme";
import { getStoredLanguage, setStoredLanguage, t, type Language } from "../lib/i18n";

interface ProfileMenuProps {
  onNavigate: (screen: string) => void;
  onOpenSignOut: () => void;
}

export default function ProfileMenu({ onNavigate, onOpenSignOut }: ProfileMenuProps) {
  const { state } = useStore();
  const [open, setOpen] = useState(false);
  const [theme, setTheme] = useState<ThemeMode>(getStoredTheme);
  const [language, setLanguage] = useState<Language>(getStoredLanguage);
  const menuRef = useRef<HTMLDivElement>(null);

  const initials = (state.account?.name ?? "S")
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  // Handle click outside & escape key
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
      }
    }

    if (open) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [open]);

  const handleThemeChange = (newTheme: ThemeMode) => {
    setTheme(newTheme);
    applyTheme(newTheme);
  };

  const handleLanguageChange = (newLang: Language) => {
    setLanguage(newLang);
    setStoredLanguage(newLang);
    // Reload or trigger state update
    window.dispatchEvent(new Event("skillbridge:lang_change"));
  };

  return (
    <div className="relative" ref={menuRef}>
      {/* Avatar Trigger button */}
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-xs text-white font-semibold shadow-xs hover:ring-2 hover:ring-indigo-300 hover:ring-offset-1 transition-all cursor-pointer focus:outline-none"
        aria-label="User Profile Menu"
        aria-expanded={open}
      >
        {initials}
      </button>

      {/* Dropdown Panel */}
      {open && (
        <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl border border-slate-200 shadow-xl py-2 z-50 animate-in fade-in zoom-in-95 duration-100 divide-y divide-slate-100">
          {/* User Profile Header */}
          <div className="px-4 py-3">
            <p className="text-xs font-semibold text-slate-800 truncate">
              {state.account?.name ?? "Student Account"}
            </p>
            <p className="text-[11px] text-slate-500 truncate mt-0.5">
              {state.account?.email ?? "student@skillbridge.local"}
            </p>
            <div className="flex items-center gap-1.5 mt-2">
              <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full font-medium">
                {state.academic.degree || "Student"}
              </span>
              <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-medium">
                {state.academic.year || "3rd"} Year
              </span>
            </div>
          </div>

          {/* Primary Navigation Links */}
          <div className="py-1">
            <button
              onClick={() => {
                onNavigate("settings");
                setOpen(false);
              }}
              className="w-full flex items-center gap-3 px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors text-left"
            >
              <UserIcon className="w-4 h-4 text-slate-400" />
              <span>{t("myProfile", language)}</span>
            </button>

            <button
              onClick={() => {
                onNavigate("assessment");
                setOpen(false);
              }}
              className="w-full flex items-center gap-3 px-4 py-2 text-xs font-medium text-indigo-700 bg-indigo-50/50 hover:bg-indigo-50 transition-colors text-left"
            >
              <CheckBadgeIcon className="w-4 h-4 text-indigo-600" />
              <span className="font-semibold">{t("takeAssessment", language)}</span>
              <span className="ml-auto text-[10px] bg-indigo-600 text-white px-1.5 py-0.2 rounded font-mono">15m</span>
            </button>

            <button
              onClick={() => {
                onNavigate("instructions");
                setOpen(false);
              }}
              className="w-full flex items-center gap-3 px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors text-left"
            >
              <BookIcon className="w-4 h-4 text-slate-400" />
              <span>{t("instructions", language)}</span>
            </button>

            <button
              onClick={() => {
                onNavigate("settings");
                setOpen(false);
              }}
              className="w-full flex items-center gap-3 px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors text-left"
            >
              <CogIcon className="w-4 h-4 text-slate-400" />
              <span>{t("settings", language)}</span>
            </button>
          </div>

          {/* Preferences: Appearance & Language */}
          <div className="p-3 space-y-2.5 bg-slate-50/50">
            {/* Appearance Selector */}
            <div>
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">
                <SunMoonIcon className="w-3.5 h-3.5" />
                <span>{t("appearance", language)}</span>
              </div>
              <div className="grid grid-cols-3 gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                {(["light", "dark", "system"] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => handleThemeChange(mode)}
                    className={`py-1 text-[10px] font-medium rounded-md transition-all capitalize ${
                      theme === mode
                        ? "bg-white text-indigo-700 shadow-xs font-semibold"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    {mode === "system" ? "System" : mode}
                  </button>
                ))}
              </div>
            </div>

            {/* Language Selector */}
            <div>
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">
                <GlobeIcon className="w-3.5 h-3.5" />
                <span>{t("language", language)}</span>
              </div>
              <div className="grid grid-cols-2 gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                <button
                  onClick={() => handleLanguageChange("en")}
                  className={`py-1 text-[10px] font-medium rounded-md transition-all ${
                    language === "en"
                      ? "bg-white text-indigo-700 shadow-xs font-semibold"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  English
                </button>
                <button
                  onClick={() => handleLanguageChange("hi")}
                  className={`py-1 text-[10px] font-medium rounded-md transition-all ${
                    language === "hi"
                      ? "bg-white text-indigo-700 shadow-xs font-semibold"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  हिन्दी
                </button>
              </div>
            </div>
          </div>

          {/* Help & Learn More */}
          <div className="py-1">
            <button
              onClick={() => {
                onNavigate("help");
                setOpen(false);
              }}
              className="w-full flex items-center gap-3 px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors text-left"
            >
              <QuestionIcon className="w-4 h-4 text-slate-400" />
              <span>{t("getHelp", language)}</span>
            </button>

            <button
              onClick={() => {
                onNavigate("learnMore");
                setOpen(false);
              }}
              className="w-full flex items-center gap-3 px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors text-left"
            >
              <SparklesIcon className="w-4 h-4 text-slate-400" />
              <span>{t("learnMore", language)}</span>
            </button>
          </div>

          {/* Sign Out */}
          <div className="py-1">
            <button
              onClick={() => {
                setOpen(false);
                onOpenSignOut();
              }}
              className="w-full flex items-center gap-3 px-4 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 transition-colors text-left"
            >
              <SignOutIcon className="w-4 h-4 text-rose-500" />
              <span>{t("signOut", language)}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Compact Icons
function UserIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="8" cy="5" r="3" />
      <path d="M2.5 14c0-3 2.5-5 5.5-5s5.5 2 5.5 5" />
    </svg>
  );
}

function CheckBadgeIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M8 1l2 2 2.8-.2.8 2.7 2.5 1.4-1 2.6 1.4 2.5-2.6 1.1-.3 2.8-2.8.2-1.8 2.1-1.8-2.1-2.8-.2-.3-2.8-2.6-1.1 1.4-2.5-1-2.6 2.5-1.4.8-2.7L6 3 8 1z" />
      <path d="M5.5 8l2 2 3.5-3.5" />
    </svg>
  );
}

function BookIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M2 3a2 2 0 012-2h9a1 1 0 011 1v11a1 1 0 01-1 1H4a2 2 0 01-2-2V3z" />
      <path d="M2 12a2 2 0 012-2h10" />
    </svg>
  );
}

function CogIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="8" cy="8" r="2.5" />
      <path d="M8 1v2M8 13v2M1 8h2M13 8h2M3 3l1.5 1.5M11.5 11.5L13 13M3 13l1.5-1.5M11.5 4.5L13 3" />
    </svg>
  );
}

function SunMoonIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="8" cy="8" r="3" />
      <path d="M8 1v1.5M8 13.5V15M1 8h1.5M13.5 8H15M3 3l1 1M12 12l1 1M3 13l1-1M12 4l1-1" />
    </svg>
  );
}

function GlobeIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="8" cy="8" r="6.5" />
      <path d="M1.5 8h13M8 1.5c2 2 2.5 4.5 2.5 6.5s-.5 4.5-2.5 6.5c-2-2-2.5-4.5-2.5-6.5S6 3.5 8 1.5z" />
    </svg>
  );
}

function QuestionIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="8" cy="8" r="7" />
      <path d="M6 6a2 2 0 113 1.7c-.5.4-1 1-1 1.8v.5M8 12.5h.01" />
    </svg>
  );
}

function SparklesIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M8 1l1.5 4 4 1.5-4 1.5L8 12l-1.5-4-4-1.5 4-1.5L8 1z" />
    </svg>
  );
}

function SignOutIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M6 2H3a1 1 0 00-1 1v10a1 1 0 001 1h3M10 11l3-3-3-3M13 8H6" />
    </svg>
  );
}
