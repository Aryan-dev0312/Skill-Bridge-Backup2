import { useState } from "react";
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, Tooltip } from "recharts";
import { CAREERS, careerById } from "../lib/catalog";
import { analyze } from "../lib/skillGap";
import { useStore } from "../lib/store";

export default function Career() {
  const { state, patch, skills } = useStore();
  const [primaryId, setPrimaryId] = useState(state.careerId ?? CAREERS[0].id);
  const [compareId, setCompareId] = useState(CAREERS.find((c) => c.id !== (state.careerId ?? CAREERS[0].id))!.id);

  const primary = careerById(primaryId)!;
  const compare = careerById(compareId)!;
  const a1 = analyze(primary.required, skills);
  const a2 = analyze(compare.required, skills);

  // Radar axes: the primary role's six most important skills
  const axes = [...primary.required].sort((x, y) => y.target * (y.weight ?? 1) - x.target * (x.weight ?? 1)).slice(0, 6);
  const chartData = axes.map((ax) => ({
    subject: ax.name,
    You: skills[ax.name]?.level ?? 0,
    [primary.title]: ax.target,
    [compare.title]: compare.required.find((r) => r.name === ax.name)?.target ?? 0,
  }));

  return (
    <div className="p-5 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-800">Career Explorer</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Compare your skills against {CAREERS.length} structured career profiles. Expected proficiency values are SkillBridge estimates, not employer requirements.
        </p>
      </div>

      {/* Pickers */}
      <div className="flex flex-wrap gap-3 mb-5">
        <div className="flex-1 min-w-48">
          <label className="text-xs font-medium text-slate-500 mb-1 block">Primary Goal</label>
          <select value={primaryId} onChange={(e) => { setPrimaryId(e.target.value); if (e.target.value === compareId) setCompareId(CAREERS.find((c) => c.id !== e.target.value)!.id); }}
            className="w-full text-sm border border-slate-200 rounded-xl px-3 py-2 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300">
            {CAREERS.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </select>
        </div>
        <div className="flex-1 min-w-48">
          <label className="text-xs font-medium text-slate-500 mb-1 block">Compare With</label>
          <select value={compareId} onChange={(e) => setCompareId(e.target.value)}
            className="w-full text-sm border border-slate-200 rounded-xl px-3 py-2 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300">
            {CAREERS.filter((c) => c.id !== primaryId).map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        {/* Radar */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-medium text-slate-700 mb-4">Skill Profile Radar</p>
          <ResponsiveContainer width="100%" height={280}>
            <RadarChart data={chartData}>
              <PolarGrid stroke="#E2E8F0" />
              <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11, fill: "#64748B" }} />
              <Radar name="You" dataKey="You" stroke="#94A3B8" fill="#94A3B8" fillOpacity={0.15} strokeDasharray="4 2" />
              <Radar name={primary.title} dataKey={primary.title} stroke="#4F46E5" fill="#4F46E5" fillOpacity={0.2} />
              <Radar name={compare.title} dataKey={compare.title} stroke="#0EA5E9" fill="#0EA5E9" fillOpacity={0.1} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
            </RadarChart>
          </ResponsiveContainer>
          <div className="flex gap-4 justify-center mt-2 flex-wrap">
            {[{ label: "You", color: "#94A3B8" }, { label: primary.title, color: "#4F46E5" }, { label: compare.title, color: "#0EA5E9" }].map((l) => (
              <div key={l.label} className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: l.color }} />
                <span className="text-[11px] text-slate-600">{l.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Readiness comparison */}
        <div className="space-y-4">
          {[{ c: primary, a: a1, color: "#4F46E5" }, { c: compare, a: a2, color: "#0EA5E9" }].map(({ c, a, color }) => (
            <div key={c.id} className="bg-white rounded-2xl border border-slate-200 p-5">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-sm font-semibold text-slate-800">{c.title}</p>
                  <p className="text-xs text-slate-500">{c.domain}</p>
                </div>
                <div className="text-2xl font-bold font-mono" style={{ color }}>{a.readiness ?? 0}%</div>
              </div>
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden mb-3">
                <div className="h-full rounded-full" style={{ width: `${a.readiness ?? 0}%`, background: color }} />
              </div>
              <div className="flex gap-2 flex-wrap">
                {a.rows.filter((r) => r.gap > 0).slice(0, 3).map((g) => (
                  <span key={g.name} className="text-[10px] bg-rose-50 text-rose-700 px-2 py-0.5 rounded-full">Gap: {g.name}</span>
                ))}
                {a.rows.every((r) => r.gap === 0) && <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full">No gaps</span>}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Role profile */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 mb-4">
        <div className="flex items-start justify-between gap-3 flex-wrap mb-3">
          <div>
            <p className="text-sm font-semibold text-slate-800">{primary.title} · Role profile</p>
            <p className="text-xs text-slate-500 mt-0.5 max-w-xl">{primary.description}</p>
          </div>
          {state.careerId === primary.id ? (
            <span className="text-[11px] bg-emerald-100 text-emerald-700 px-3 py-1.5 rounded-xl font-medium">✓ Your target career</span>
          ) : (
            <button onClick={() => patch({ careerId: primary.id })} className="text-xs bg-indigo-600 text-white px-3 py-2 rounded-xl font-medium hover:bg-indigo-700">Set as my target career</button>
          )}
        </div>
        <p className="text-xs font-medium text-slate-500 mb-2">Required skills and expected proficiency</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-4">
          {a1.rows.map((r) => (
            <div key={r.name} className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg">
              <div className={`w-1.5 h-1.5 rounded-full ${r.gap === 0 ? "bg-emerald-500" : r.severity === "high" ? "bg-rose-500" : "bg-amber-400"}`} />
              <span className="text-sm text-slate-700 flex-1">{r.name}</span>
              <span className="text-[11px] font-mono text-slate-500">{r.current}/{r.target}</span>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[["Preferred skills", primary.preferred], ["Languages", primary.languages], ["Frameworks", primary.frameworks], ["Tools", primary.tools]].map(([label, items]) => (
            <div key={label as string}>
              <p className="text-xs font-medium text-slate-500 mb-1.5">{label as string}</p>
              <div className="flex flex-wrap gap-1.5">
                {(items as string[]).map((i) => <span key={i} className="text-[11px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">{i}</span>)}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4">
          <p className="text-xs font-medium text-slate-500 mb-1.5">Example projects</p>
          <ul className="space-y-1">{primary.projects.map((p) => <li key={p} className="text-sm text-slate-700 flex gap-2"><span className="text-indigo-400">•</span>{p}</li>)}</ul>
        </div>
      </div>

      {/* Required skills table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <p className="text-sm font-medium text-slate-700 mb-4">Required Skills Comparison</p>
        <div className="grid grid-cols-2 gap-4">
          {[primary, compare].map((c, i) => (
            <div key={c.id}>
              <p className="text-xs font-medium mb-2" style={{ color: i === 0 ? "#4F46E5" : "#0EA5E9" }}>{c.title}</p>
              <div className="space-y-2">
                {c.required.map((s) => (
                  <div key={s.name} className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full" style={{ background: i === 0 ? "#4F46E5" : "#0EA5E9" }} />
                    <span className="text-sm text-slate-700">{s.name}</span>
                    <span className="ml-auto text-[11px] font-mono text-slate-400">{s.target}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
