// Pure scoring logic. No React imports so it can be tested in isolation.
// Data contract (see project notes): name, current, target, gap, weight?

export type Status = "self" | "assessed" | "verified";
export type Severity = "high" | "medium" | "low" | "met";

export interface Requirement {
  name: string;
  target: number; // 0-100
  weight?: number; // > 0, defaults to 1
}

export interface SkillResult {
  name: string;
  current: number;
  target: number;
  gap: number;
  weight: number;
  severity: Severity;
  status: Status | null; // null = student has not listed this skill
  missing: boolean; // not listed by the student at all
  invalid: boolean; // a score or weight was out of range and was corrected
}

export const isValidScore = (n: unknown): n is number =>
  typeof n === "number" && Number.isFinite(n) && n >= 0 && n <= 100;

export const clampScore = (n: unknown): number =>
  typeof n === "number" && Number.isFinite(n) ? Math.min(100, Math.max(0, Math.round(n))) : 0;

export const computeGap = (current: number, target: number): number => Math.max(0, target - current);

// Documented rule: high >= 40, medium 20-39, low 1-19, met = 0
export function severityOf(gap: number): Severity {
  if (gap <= 0) return "met";
  if (gap >= 40) return "high";
  if (gap >= 20) return "medium";
  return "low";
}

export interface SkillInput {
  level: number;
  status: Status;
}

export function analyze(
  requirements: Requirement[],
  skills: Record<string, SkillInput>,
): { rows: SkillResult[]; readiness: number | null; counts: Record<Severity, number> } {
  const rows: SkillResult[] = requirements.map((r) => {
    const own = skills[r.name];
    const weightOk = typeof r.weight !== "number" || (Number.isFinite(r.weight) && r.weight > 0);
    const invalid = !isValidScore(r.target) || (own !== undefined && !isValidScore(own.level)) || !weightOk;
    const target = clampScore(r.target);
    const current = own ? clampScore(own.level) : 0;
    const gap = computeGap(current, target);
    return {
      name: r.name,
      current,
      target,
      gap,
      weight: weightOk ? r.weight ?? 1 : 1,
      severity: severityOf(gap),
      status: own ? own.status : null,
      missing: !own,
      invalid,
    };
  });

  const counts: Record<Severity, number> = { high: 0, medium: 0, low: 0, met: 0 };
  rows.forEach((r) => counts[r.severity]++);

  // Weighted readiness is an ESTIMATE of coverage of the role's expected proficiency,
  // not a hiring probability.
  const denom = rows.reduce((s, r) => s + r.weight * r.target, 0);
  const num = rows.reduce((s, r) => s + r.weight * Math.min(r.current, r.target), 0);
  const readiness = rows.length > 0 && denom > 0 ? Math.round((num / denom) * 100) : null;

  rows.sort((a, b) => b.gap * b.weight - a.gap * a.weight || a.name.localeCompare(b.name));
  return { rows, readiness, counts };
}
