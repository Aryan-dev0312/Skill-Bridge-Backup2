import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from "recharts";
import { useStore } from "../lib/store";

const fmt = (iso: string) => new Date(iso).toLocaleDateString("en", { day: "numeric", month: "short" });

export default function Progress() {
  const { state, skills, rows, readiness, roadmap, taskStats, assessment } = useStore();
  const history = state.history.map((h) => ({ date: fmt(h.t), score: h.readiness }));
  const first = state.history[0]?.readiness ?? readiness ?? 0;
  const growth = (readiness ?? 0) - first;

  // tasks completed per roadmap phase
  const perPhase = roadmap.phases.map((p) => ({ phase: `P${p.phase}`, done: p.tasks.filter((t) => state.completedTasks[t.id]).length, total: p.tasks.length }));
  const growthRows = rows.filter((r) => state.initialLevels[r.name] !== undefined || r.current > 0).slice(0, 6).map((r) => ({
    skill: r.name, start: state.initialLevels[r.name] ?? 0, current: r.current,
  }));
  const completedProjects = state.projects.filter((p) => p.status === "completed").length;

  const achievements = [
    { title: "Profile Built", desc: "Finished onboarding", icon: "✅", earned: state.onboarded },
    { title: "Diagnostic Taken", desc: "Completed all 5 questions", icon: "🧪", earned: !!assessment },
    { title: "First Task Done", desc: "Completed a roadmap task", icon: "🔥", earned: taskStats.done >= 1 },
    { title: "Halfway There", desc: "50% of the roadmap done", icon: "🧭", earned: taskStats.pct >= 50 },
    { title: "Project Builder", desc: "Completed a project", icon: "🏗️", earned: completedProjects >= 1 },
    { title: "Role Ready (est.)", desc: "Readiness estimate 85%+", icon: "🎯", earned: (readiness ?? 0) >= 85 },
  ];

  return (
    <div className="p-5 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-800">Progress Analytics</h1>
        <p className="text-sm text-slate-500 mt-0.5">Everything here is calculated from your own saved activity.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        {[
          { label: "Readiness Change", value: `${growth >= 0 ? "+" : ""}${growth}%`, sub: `from ${first}% to ${readiness ?? 0}% (estimate)`, color: growth >= 0 ? "text-emerald-600" : "text-rose-600" },
          { label: "Skills Tracked", value: String(Object.keys(skills).length), sub: `${Object.values(skills).filter((s) => s.status === "assessed").length} assessed`, color: "text-indigo-600" },
          { label: "Tasks Completed", value: `${taskStats.done}/${taskStats.total}`, sub: `${taskStats.pct}% of roadmap`, color: "text-sky-600" },
          { label: "Projects", value: String(state.projects.length), sub: `${completedProjects} completed`, color: "text-amber-600" },
        ].map((m) => (
          <div key={m.label} className="bg-white rounded-2xl border border-slate-200 p-4">
            <p className="text-xs text-slate-500 font-medium mb-1">{m.label}</p>
            <p className={`text-2xl font-bold font-mono ${m.color}`}>{m.value}</p>
            <p className="text-[11px] text-slate-400 mt-1">{m.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-medium text-slate-700 mb-4">Career Readiness Trend</p>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={history} margin={{ top: 0, right: 16, bottom: 0, left: -16 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94A3B8" }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: "#94A3B8" }} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} formatter={(v) => [`${v}%`, "Readiness (estimate)"]} />
              <Line type="monotone" dataKey="score" stroke="#4F46E5" strokeWidth={2.5} dot={{ fill: "#4F46E5", r: 4 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
          <p className="text-[11px] text-slate-400 mt-1">A new point is recorded whenever your readiness estimate changes.</p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-sm font-medium text-slate-700 mb-4">Tasks Completed by Roadmap Phase</p>
          {perPhase.length === 0 ? <p className="text-sm text-slate-500">No roadmap yet: no gaps to plan for.</p> : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={perPhase} margin={{ top: 0, right: 0, bottom: 0, left: -16 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                <XAxis dataKey="phase" tick={{ fontSize: 11, fill: "#94A3B8" }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#94A3B8" }} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} formatter={(v, n) => [`${v}`, n === "done" ? "Done" : "Total"]} />
                <Bar dataKey="total" radius={[4, 4, 0, 0]} fill="#E0E7FF" />
                <Bar dataKey="done" radius={[4, 4, 0, 0]}>{perPhase.map((_, i) => <Cell key={i} fill="#4F46E5" />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-5 mb-4">
        <p className="text-sm font-medium text-slate-700 mb-4">Skill Growth (Start vs Current)</p>
        <div className="space-y-4">
          {growthRows.map((s) => {
            const g = s.current - s.start;
            return (
              <div key={s.skill}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-sm font-medium text-slate-700">{s.skill}</span>
                  <span className={`text-xs font-mono ${g > 0 ? "text-emerald-600" : "text-slate-400"}`}>{g > 0 ? `+${g}` : g}%</span>
                </div>
                <div className="relative h-3 bg-slate-100 rounded-full overflow-hidden">
                  <div className="absolute h-full rounded-full bg-slate-300" style={{ width: `${Math.min(s.start, s.current)}%` }} />
                  {g > 0 && <div className="absolute h-full rounded-full bg-indigo-500" style={{ left: `${s.start}%`, width: `${g}%` }} />}
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 mt-0.5"><span>Started: {s.start}%</span><span>Now: {s.current}%</span></div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <p className="text-sm font-medium text-slate-700 mb-4">Achievements</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {achievements.map((a) => (
            <div key={a.title} className={`flex flex-col items-center text-center p-3 rounded-xl transition-all ${a.earned ? "bg-indigo-50 border border-indigo-100" : "bg-slate-50 border border-slate-100 opacity-50"}`}>
              <span className="text-2xl mb-2">{a.icon}</span>
              <p className="text-xs font-semibold text-slate-800 leading-tight">{a.title}</p>
              <p className="text-[10px] text-slate-500 mt-0.5">{a.desc}</p>
              {!a.earned && <span className="text-[9px] text-slate-400 mt-1">Locked</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
