import { useState, useEffect, useRef, useMemo } from "react";
import {
  COMPREHENSIVE_QUESTIONS,
  ASSESSMENT_DOMAINS,
  type AssessmentQuestion,
} from "../lib/assessmentData";
import { useStore, type ComprehensiveAssessmentResult } from "../lib/store";

interface ComprehensiveAssessmentProps {
  onBackToDashboard?: () => void;
  onNavigate?: (screen: string) => void;
}

export default function ComprehensiveAssessment({
  onBackToDashboard,
  onNavigate,
}: ComprehensiveAssessmentProps) {
  const { state, saveComprehensiveAssessment } = useStore();

  const [selectedDomains, setSelectedDomains] = useState<string[]>([...ASSESSMENT_DOMAINS]);
  const [status, setStatus] = useState<"intro" | "active" | "results">("intro");

  const activeQuestions = useMemo(() => {
    return COMPREHENSIVE_QUESTIONS.filter((q) => selectedDomains.includes(q.domain));
  }, [selectedDomains]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [flagged, setFlagged] = useState<Record<string, boolean>>({});
  const [timeLeft, setTimeLeft] = useState(15 * 60); // 900 seconds
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [showPalette, setShowPalette] = useState(false);
  const [reviewMode, setReviewMode] = useState(false);

  const [lastResult, setLastResult] = useState<ComprehensiveAssessmentResult | null>(null);

  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (status !== "active") return;

    timerRef.current = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [status, answers, activeQuestions]);

  const handleStart = () => {
    setCurrentIndex(0);
    setAnswers({});
    setFlagged({});
    setTimeLeft(15 * 60);
    setStatus("active");
  };

  const selectOption = (optIndex: number) => {
    const q = activeQuestions[currentIndex];
    setAnswers((prev) => ({ ...prev, [q.id]: optIndex }));
  };

  const toggleFlagCurrent = () => {
    const q = activeQuestions[currentIndex];
    setFlagged((prev) => ({ ...prev, [q.id]: !prev[q.id] }));
  };

  const handleSubmit = () => {
    setShowSubmitModal(false);
    if (timerRef.current) clearInterval(timerRef.current);

    let correctCount = 0;
    const domainStats: Record<string, { total: number; score: number; pct: number }> = {};
    const evaluatedSkills: Record<string, { level: number; passed: boolean }> = {};

    activeQuestions.forEach((q) => {
      const isCorrect = answers[q.id] === q.answer;
      if (isCorrect) correctCount++;

      if (!domainStats[q.domain]) {
        domainStats[q.domain] = { total: 0, score: 0, pct: 0 };
      }
      domainStats[q.domain].total++;
      if (isCorrect) domainStats[q.domain].score++;

      const existing = evaluatedSkills[q.relatedSkill];
      const passingScore = isCorrect
        ? q.difficulty === "Advanced"
          ? 85
          : q.difficulty === "Intermediate"
          ? 75
          : 65
        : 35;
      if (!existing || isCorrect) {
        evaluatedSkills[q.relatedSkill] = {
          level: existing ? Math.max(existing.level, passingScore) : passingScore,
          passed: isCorrect,
        };
      }
    });

    Object.keys(domainStats).forEach((d) => {
      domainStats[d].pct = Math.round((domainStats[d].score / domainStats[d].total) * 100);
    });

    const result: ComprehensiveAssessmentResult = {
      id: "assess_" + Date.now(),
      timestamp: new Date().toISOString(),
      durationSeconds: 15 * 60 - timeLeft,
      totalQuestions: activeQuestions.length,
      score: correctCount,
      accuracy: Math.round((correctCount / activeQuestions.length) * 100),
      domainBreakdown: domainStats,
      userAnswers: answers,
      assessedSkills: evaluatedSkills,
    };

    setLastResult(result);
    saveComprehensiveAssessment(result);
    setStatus("results");
  };

  const currentQ = activeQuestions[currentIndex];
  const answeredCount = Object.keys(answers).length;
  const flaggedCount = Object.values(flagged).filter(Boolean).length;
  const unansweredCount = activeQuestions.length - answeredCount;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;

  // -------------------------------------------------------------
  // VIEW 1: INTRO & DOMAIN SELECTOR
  // -------------------------------------------------------------
  if (status === "intro") {
    return (
      <div className="p-4 sm:p-6 max-w-5xl mx-auto">
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold bg-blue-50 text-blue-700 px-3 py-1 rounded-full border border-blue-200">
                  <span>★</span>
                  <span>Screening Benchmark</span>
                </span>
                <span className="text-[11px] font-semibold bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-full">
                  15 Minutes
                </span>
              </div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
                SkillBridge 15-Minute Technical Assessment
              </h1>
              <p className="text-xs text-slate-500 mt-1 max-w-2xl">
                Standardized evaluation across 9 technical categories. Compare your performance against the candidate pool and elevate your assessed skill profile.
              </p>
            </div>
            {onBackToDashboard && (
              <button
                onClick={onBackToDashboard}
                className="self-start sm:self-auto text-xs text-slate-500 hover:text-slate-800 border border-slate-200 px-3.5 py-2 rounded-xl font-medium transition-colors"
              >
                ← Back to Dashboard
              </button>
            )}
          </div>

          {/* Guidelines */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
              <span className="text-blue-600 font-bold text-sm">⏱ 15 Minutes Exact</span>
              <p className="text-xs text-slate-600">
                Auto-submits when the timer reaches 00:00. Each question allows ~30 seconds average.
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
              <span className="text-indigo-600 font-bold text-sm">🎯 30 Questions</span>
              <p className="text-xs text-slate-600">
                Single correct answer per question. Navigate back and forth or flag questions for review.
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
              <span className="text-emerald-600 font-bold text-sm">📊 Live Ranking</span>
              <p className="text-xs text-slate-600">
                Percentile distribution, domain-wise scorecards, and verified skill updates upon submit.
              </p>
            </div>
          </div>

          {/* Domain Selection */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Domains Tested ({activeQuestions.length} Questions)
              </h3>
              <button
                onClick={() => setSelectedDomains([...ASSESSMENT_DOMAINS])}
                className="text-xs text-blue-600 hover:underline font-semibold"
              >
                Select All
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {ASSESSMENT_DOMAINS.map((domain) => {
                const count = COMPREHENSIVE_QUESTIONS.filter((q) => q.domain === domain).length;
                const isChecked = selectedDomains.includes(domain);
                return (
                  <button
                    key={domain}
                    type="button"
                    onClick={() => {
                      if (isChecked && selectedDomains.length > 1) {
                        setSelectedDomains(selectedDomains.filter((d) => d !== domain));
                      } else if (!isChecked) {
                        setSelectedDomains([...selectedDomains, domain]);
                      }
                    }}
                    className={`flex items-center justify-between p-3 rounded-xl border text-left text-xs font-medium transition-all ${
                      isChecked
                        ? "border-blue-400 bg-blue-50/60 text-blue-900 font-semibold shadow-xs"
                        : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                    }`}
                  >
                    <span className="truncate pr-2">{domain}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-md font-mono bg-white border border-slate-200 text-slate-500">
                      {count} Qs
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* CTA */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-100">
            <p className="text-xs text-slate-500">
              Timer starts immediately. Correct answers will not be revealed until final submission.
            </p>
            <button
              onClick={handleStart}
              className="w-full sm:w-auto px-8 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md hover:shadow-blue-200 transition-all flex items-center justify-center gap-2"
            >
              <span>Start Assessment</span>
              <span>→</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // VIEW 2: ACTIVE ASSESSMENT (Matching Page 2 Reference UI)
  // -------------------------------------------------------------
  if (status === "active") {
    const candidateScoreEst = Math.min(100, Math.max(30, Math.round((answeredCount / activeQuestions.length) * 85)));

    return (
      <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-4">
        {/* Top Floating Badge (Matching "★ Shortlisted" pill in Page 2) */}
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white border border-blue-200 text-blue-700 text-xs font-bold shadow-xs">
            <span className="text-blue-600">★</span>
            <span>Technical Assessment Active</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Timer Badge */}
            <div
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full font-mono text-xs font-bold border transition-colors ${
                timeLeft < 120
                  ? "bg-rose-50 border-rose-300 text-rose-600 animate-pulse"
                  : "bg-white border-slate-200 text-slate-700 shadow-xs"
              }`}
            >
              <span>⏱</span>
              <span>{formattedTime}</span>
            </div>

            <button
              onClick={() => setShowPalette(!showPalette)}
              className="px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors"
            >
              {showPalette ? "Hide Grid" : "Palette (1-30)"}
            </button>
          </div>
        </div>

        {/* Collapsible Palette */}
        {showPalette && (
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm animate-in fade-in duration-100">
            <div className="flex items-center justify-between mb-3 text-xs">
              <span className="font-bold text-slate-800">Quick Navigation</span>
              <span className="text-slate-500">
                {answeredCount} of {activeQuestions.length} answered · {flaggedCount} flagged
              </span>
            </div>
            <div className="grid grid-cols-6 sm:grid-cols-10 gap-1.5">
              {activeQuestions.map((q, idx) => (
                <button
                  key={q.id}
                  onClick={() => {
                    setCurrentIndex(idx);
                    setShowPalette(false);
                  }}
                  className={`h-8 rounded-lg text-xs font-bold font-mono transition-all ${
                    idx === currentIndex
                      ? "ring-2 ring-blue-600 ring-offset-1 bg-blue-600 text-white"
                      : answers[q.id] !== undefined
                      ? "bg-blue-100 text-blue-800"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  {idx + 1}
                  {flagged[q.id] && "★"}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* MAIN QUESTION & EVALUATION ROW (Matching Page 2 Reference) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-start">
          {/* Main Question Card (2 Columns - Matching Left Card in Page 2) */}
          <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-5">
            {/* Question Number */}
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-500 uppercase tracking-wider">
                Question {currentIndex + 1}/{activeQuestions.length}
              </h2>
              <button
                onClick={toggleFlagCurrent}
                className={`text-xs font-semibold px-2.5 py-1 rounded-lg border transition-colors ${
                  flagged[currentQ.id]
                    ? "bg-amber-50 border-amber-300 text-amber-700"
                    : "border-slate-200 text-slate-500 hover:bg-slate-50"
                }`}
              >
                {flagged[currentQ.id] ? "★ Flagged" : "☆ Flag"}
              </button>
            </div>

            {/* Question Prompt */}
            <div className="space-y-3">
              <p className="text-base sm:text-lg font-semibold text-slate-900 leading-snug">
                {currentQ.prompt}
              </p>

              {/* Code snippet if any (styled like Page 2 code block) */}
              <div className="bg-slate-950 text-slate-100 rounded-xl p-3.5 font-mono text-xs overflow-x-auto border border-slate-800">
                <span className="text-slate-500 block mb-1 text-[10px] uppercase font-sans">
                  // {currentQ.subtopic}
                </span>
                <code>print(type([1, 2, 3]))</code>
              </div>
            </div>

            {/* Options Header (Matching Page 2) */}
            <div>
              <p className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
                Select your answer
              </p>

              {/* Options Radio List */}
              <div className="space-y-2.5">
                {currentQ.options.map((optText, optIdx) => {
                  const isSelected = answers[currentQ.id] === optIdx;
                  const letter = String.fromCharCode(97 + optIdx); // a, b, c, d
                  return (
                    <button
                      key={optIdx}
                      type="button"
                      onClick={() => selectOption(optIdx)}
                      className={`w-full text-left p-3.5 rounded-2xl border text-xs sm:text-sm transition-all flex items-center gap-3 ${
                        isSelected
                          ? "border-blue-500 bg-blue-50/70 text-blue-950 font-semibold ring-2 ring-blue-200 shadow-xs"
                          : "border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50/70"
                      }`}
                    >
                      {/* Radio Circle Indicator */}
                      <span
                        className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                          isSelected
                            ? "border-blue-600 bg-blue-600"
                            : "border-slate-300 bg-white"
                        }`}
                      >
                        {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </span>

                      {/* Letter & Option Text (e.g. "a. <class 'set'>") */}
                      <span className="font-semibold text-slate-500">{letter}.</span>
                      <span className="flex-1 font-mono text-xs">{optText}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Floating Evaluation & Benchmark Card (Matching Page 2 Right Widget) */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            {/* Domain & Good Pill */}
            <div className="text-center space-y-1.5">
              <h3 className="text-base font-bold text-slate-900">{currentQ.domain}</h3>
              <span className="inline-block px-3 py-0.5 rounded-full font-bold text-[11px] bg-emerald-100 text-emerald-700 uppercase tracking-wider">
                GOOD
              </span>
            </div>

            {/* Dual Semicircle Gauges (Matching Page 2) */}
            <div className="flex items-center justify-center gap-6 pt-2">
              {/* Candidate Gauge */}
              <div className="flex flex-col items-center">
                <div className="relative w-16 h-12 flex items-center justify-center">
                  <svg viewBox="0 0 100 55" className="w-full h-full overflow-visible">
                    <path
                      d="M 10 50 A 40 40 0 0 1 90 50"
                      fill="none"
                      stroke="#E2E8F0"
                      strokeWidth="10"
                      strokeLinecap="round"
                    />
                    <path
                      d="M 10 50 A 40 40 0 0 1 90 50"
                      fill="none"
                      stroke="#10B981"
                      strokeWidth="10"
                      strokeDasharray="126"
                      strokeDashoffset={126 - (candidateScoreEst / 100) * 126}
                      strokeLinecap="round"
                    />
                  </svg>
                  <span className="absolute bottom-0 text-sm font-bold font-mono text-slate-900">
                    {candidateScoreEst}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-medium mt-1">Candidate</span>
              </div>

              {/* Pool Avg Gauge */}
              <div className="flex flex-col items-center">
                <div className="relative w-16 h-12 flex items-center justify-center">
                  <svg viewBox="0 0 100 55" className="w-full h-full overflow-visible">
                    <path
                      d="M 10 50 A 40 40 0 0 1 90 50"
                      fill="none"
                      stroke="#E2E8F0"
                      strokeWidth="10"
                      strokeLinecap="round"
                    />
                    <path
                      d="M 10 50 A 40 40 0 0 1 90 50"
                      fill="none"
                      stroke="#64748B"
                      strokeWidth="10"
                      strokeDasharray="126"
                      strokeDashoffset={126 - (55 / 100) * 126}
                      strokeLinecap="round"
                    />
                  </svg>
                  <span className="absolute bottom-0 text-sm font-bold font-mono text-slate-600">
                    55
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-medium mt-1">Pool Avg</span>
              </div>
            </div>

            {/* Level & Completion Time (Matching Page 2) */}
            <div className="pt-3 border-t border-slate-100 text-center space-y-1 text-xs">
              <p className="font-semibold text-slate-700">
                Level: <span className="text-amber-500">★★</span> {currentQ.difficulty}
              </p>
              <p className="text-[11px] text-slate-400">
                Completion time: {Math.floor((15 * 60 - timeLeft) / 60)}&apos;
              </p>
            </div>
          </div>
        </div>

        {/* BOTTOM NAVIGATION & RANK BAR (Matching Page 2 Bottom Bar) */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white rounded-3xl border border-slate-200 p-4 sm:p-5 shadow-xs">
          {/* Overall Rank Pill (Matching Page 2: "1/30" + "OVERALL RANK Top 5% compared to the Candidate Pool") */}
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <span className="text-xl sm:text-2xl font-bold font-mono text-slate-900">
              {currentIndex + 1}/{activeQuestions.length}
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-sm shrink-0">
              ★
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Overall Rank
              </p>
              <p className="text-xs font-semibold text-slate-800">
                Top 5% compared to Candidate Pool
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <button
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>

            {currentIndex < activeQuestions.length - 1 ? (
              <button
                onClick={() => setCurrentIndex((prev) => Math.min(activeQuestions.length - 1, prev + 1))}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md hover:shadow-blue-200 transition-all"
              >
                Next Question
              </button>
            ) : (
              <button
                onClick={() => setShowSubmitModal(true)}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md hover:shadow-emerald-200 transition-all"
              >
                Review & Submit
              </button>
            )}

            <button
              onClick={() => setShowSubmitModal(true)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-semibold shadow-xs transition-colors"
            >
              Finish
            </button>
          </div>
        </div>

        {/* Submit Confirmation Modal */}
        {showSubmitModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
            <div className="bg-white rounded-3xl border border-slate-200 p-6 max-w-sm w-full shadow-2xl space-y-4">
              <h3 className="text-base font-bold text-slate-900">
                Submit Assessment?
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                You have answered <span className="font-bold text-blue-600">{answeredCount}</span> of {activeQuestions.length} questions. {unansweredCount > 0 && <span className="text-rose-600 font-semibold">{unansweredCount} remain unanswered.</span>}
              </p>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowSubmitModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Continue Test
                </button>
                <button
                  onClick={handleSubmit}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm"
                >
                  Confirm & Submit
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // -------------------------------------------------------------
  // VIEW 3: SCORECARD / REPORT (Matching Page 3 HirePro Reference)
  // -------------------------------------------------------------
  if (status === "results" && lastResult) {
    const accuracy = lastResult.accuracy;
    const testId = lastResult.id.replace("assess_", "");
    const minutesTaken = Math.floor(lastResult.durationSeconds / 60);
    const secondsTaken = lastResult.durationSeconds % 60;
    const dateFormatted = new Date(lastResult.timestamp).toLocaleDateString();

    return (
      <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-5">
        {/* Top 7-Metrics Strip (Matching Page 3 Top Bar) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 bg-white rounded-2xl border border-slate-200 p-3 shadow-xs text-center">
          <div className="p-2">
            <p className="text-sm font-bold text-slate-800">Python</p>
            <p className="text-[10px] text-slate-400">Selected Track</p>
            <span className="text-[9px] text-slate-400">51% uses Python</span>
          </div>
          <div className="p-2 border-l border-slate-100">
            <p className="text-sm font-bold text-blue-600 font-mono">
              {lastResult.score}/{lastResult.totalQuestions}
            </p>
            <p className="text-[10px] text-slate-400">Test Cases Passed</p>
            <span className="text-[9px] text-slate-400">Average: 18/30</span>
          </div>
          <div className="p-2 border-l border-slate-100">
            <p className="text-sm font-bold text-slate-800 font-mono">
              {minutesTaken}m {secondsTaken}s
            </p>
            <p className="text-[10px] text-slate-400">Time to Solve</p>
            <span className="text-[9px] text-slate-400">Average: 9m 10s</span>
          </div>
          <div className="p-2 border-l border-slate-100">
            <p className="text-sm font-bold text-slate-800 font-mono">345ns</p>
            <p className="text-[10px] text-slate-400">Avg. Execution Time</p>
            <span className="text-[9px] text-slate-400">Average: 421ns</span>
          </div>
          <div className="p-2 border-l border-slate-100">
            <p className="text-sm font-bold text-slate-800 font-mono">100kB</p>
            <p className="text-[10px] text-slate-400">Memory Consumption</p>
            <span className="text-[9px] text-slate-400">Average: 95kB</span>
          </div>
          <div className="p-2 border-l border-slate-100">
            <p className="text-sm font-bold text-slate-800 font-mono">23</p>
            <p className="text-[10px] text-slate-400">Code Complexity</p>
            <span className="text-[9px] text-slate-400">Average: 31</span>
          </div>
          <div className="p-2 border-l border-slate-100">
            <p className="text-sm font-bold text-slate-800 font-mono">56</p>
            <p className="text-[10px] text-slate-400">Lines of Code</p>
            <span className="text-[9px] text-slate-400">Average: 67</span>
          </div>
        </div>

        {/* Assessment Report Header (Matching Page 3) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold text-slate-900">Assessment Report</h1>
            <div className="flex items-center gap-3 text-xs text-slate-500 mt-1 font-mono">
              <span>Test ID: <strong className="text-blue-600">{testId.slice(-6)}</strong></span>
              <span>• Attended Date: {dateFormatted}</span>
              <span>• Time Taken: {minutesTaken}m {secondsTaken}s</span>
            </div>
          </div>

          {/* Right Indicator Bars (Matching Page 3) */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-semibold">
              Overall Performance: <strong className="text-slate-800">{accuracy >= 75 ? "High" : "Medium"}</strong>
            </span>
            <div className="flex gap-1">
              <span className="w-6 h-1.5 rounded-full bg-amber-400" />
              <span className={`w-6 h-1.5 rounded-full ${accuracy >= 60 ? "bg-amber-400" : "bg-slate-200"}`} />
              <span className={`w-6 h-1.5 rounded-full ${accuracy >= 75 ? "bg-emerald-500" : "bg-slate-200"}`} />
            </div>
          </div>
        </div>

        {/* TWO MAIN PANELS: Candidate Ranking & Candidate Marks (Matching Page 3) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Panel 1: Candidate Ranking (Matching Page 3 Left Box) */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Candidate Ranking</h2>
              <p className="text-[11px] text-slate-400">Candidate&apos;s position compared to others who took the test</p>
            </div>

            {/* Rank Stat Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-cyan-500 text-white font-mono">
                <p className="text-2xl font-bold">
                  {Math.max(1, Math.round((1 - accuracy / 100) * 150))}/150
                </p>
                <p className="text-[11px] text-cyan-100 font-sans mt-0.5">Candidate Rank</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 font-mono">
                <p className="text-2xl font-bold text-slate-800">
                  {Math.min(99, Math.max(50, accuracy))}th
                </p>
                <p className="text-[11px] text-slate-500 font-sans mt-0.5">Percentile</p>
              </div>
            </div>

            {/* Bell Curve Normal Distribution (Matching Page 3) */}
            <div className="relative w-full h-32 pt-2">
              <svg viewBox="0 0 350 90" className="w-full h-full overflow-visible">
                <defs>
                  <linearGradient id="rankBellGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#F87171" stopOpacity="0.8" />
                    <stop offset="50%" stopColor="#FBBF24" stopOpacity="0.85" />
                    <stop offset="100%" stopColor="#34D399" stopOpacity="0.9" />
                  </linearGradient>
                </defs>
                <path
                  d="M 10,75 C 60,75 100,60 140,25 C 165,5 185,5 210,25 C 250,60 290,75 340,75 L 340,82 L 10,82 Z"
                  fill="url(#rankBellGrad)"
                />
                <line x1="10" y1="80" x2="340" y2="80" stroke="#CBD5E1" strokeWidth="1" />

                {/* Candidate Pointer Marker */}
                <g transform={`translate(${Math.min(310, Math.max(40, (accuracy / 100) * 270 + 40))}, 28)`}>
                  <circle cx="0" cy="0" r="4.5" fill="#0F172A" stroke="#FFFFFF" strokeWidth="2" />
                  <rect x="-32" y="-20" width="64" height="16" rx="4" fill="#0F172A" />
                  <text x="0" y="-9" textAnchor="middle" fill="#FFFFFF" fontSize="8" fontWeight="bold">
                    {state.account?.name?.split(" ")[0] || "Candidate"}
                  </text>
                </g>
              </svg>
            </div>
          </div>

          {/* Panel 2: Candidate Marks & Breakdown (Matching Page 3 Right Box) */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Candidate Marks</h2>
              <p className="text-[11px] text-slate-400">Detailed score evaluation and question performance</p>
            </div>

            {/* 4 Stat Cards (Matching Page 3) */}
            <div className="grid grid-cols-4 gap-2 text-center font-mono">
              <div className="p-2.5 rounded-xl bg-cyan-500 text-white">
                <p className="text-base font-bold">{lastResult.score}/{lastResult.totalQuestions}</p>
                <p className="text-[9px] text-cyan-100 font-sans">Marks Scored</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-base font-bold text-slate-800">{lastResult.accuracy}%</p>
                <p className="text-[9px] text-slate-500 font-sans">Percentage</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-base font-bold text-slate-800">18/{lastResult.totalQuestions}</p>
                <p className="text-[9px] text-slate-500 font-sans">Avg Score</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-base font-bold text-slate-800">29/{lastResult.totalQuestions}</p>
                <p className="text-[9px] text-slate-500 font-sans">Highest</p>
              </div>
            </div>

            {/* Horizontal Bar Breakdown (Matching Page 3) */}
            <div className="space-y-2 pt-2 text-xs">
              {Object.entries(lastResult.domainBreakdown).slice(0, 5).map(([dom, st]) => (
                <div key={dom} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="font-semibold text-slate-700 truncate pr-2">{dom}</span>
                    <span className="font-mono text-slate-500">{st.score}/{st.total}</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden flex">
                    <div
                      className="h-full bg-cyan-500 rounded-full transition-all"
                      style={{ width: `${st.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Legend (Matching Page 3) */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-100">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1.5 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded bg-cyan-500" />
                  <span>Marks Scored</span>
                </span>
                <span className="flex items-center gap-1.5 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded bg-slate-200" />
                  <span>Total Marks</span>
                </span>
              </div>
              <button
                onClick={() => setReviewMode(!reviewMode)}
                className="text-blue-600 hover:underline font-semibold"
              >
                {reviewMode ? "Hide Questions" : "Click here to view more"}
              </button>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <button
            onClick={() => setReviewMode(!reviewMode)}
            className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            {reviewMode ? "Hide Technical Explanations" : "Review All 30 Questions & Explanations ↓"}
          </button>

          <div className="flex gap-2">
            <button
              onClick={handleStart}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Retake Assessment
            </button>
            {onBackToDashboard && (
              <button
                onClick={onBackToDashboard}
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors"
              >
                Go to Dashboard →
              </button>
            )}
          </div>
        </div>

        {/* Detailed Question Review (Collapsible) */}
        {reviewMode && (
          <div className="space-y-3 pt-4 border-t border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Comprehensive Review & Explanations
            </h3>
            {activeQuestions.map((q, idx) => {
              const userAns = lastResult.userAnswers[q.id];
              const isCorrect = userAns === q.answer;
              return (
                <div
                  key={q.id}
                  className={`p-4 rounded-2xl border bg-white shadow-xs ${
                    isCorrect ? "border-emerald-200" : "border-rose-200"
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-bold text-slate-800">
                      Q{idx + 1}. {q.domain} ({q.subtopic})
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        isCorrect ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"
                      }`}
                    >
                      {isCorrect ? "Correct ✓" : "Incorrect ✗"}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-slate-900 mb-2">{q.prompt}</p>
                  <p className="text-[11px] text-slate-600">
                    <strong>Correct answer:</strong> {q.options[q.answer]}
                  </p>
                  <p className="text-[11px] text-blue-900 bg-blue-50/70 p-2.5 rounded-xl mt-2 border border-blue-100">
                    <strong>Explanation:</strong> {q.explanation}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  return null;
}
