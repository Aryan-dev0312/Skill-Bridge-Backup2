interface LearnMoreProps {
  onNavigate?: (screen: string) => void;
}

export default function LearnMore({ onNavigate }: LearnMoreProps) {
  return (
    <div className="p-5 max-w-5xl mx-auto space-y-6">
      {/* Hero Banner */}
      <div className="bg-gradient-to-br from-indigo-900 via-indigo-800 to-slate-900 rounded-3xl p-8 sm:p-10 text-white shadow-lg relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-72 h-72 rounded-full bg-violet-500/20 blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-2xl space-y-3">
          <span className="text-[11px] font-mono font-semibold bg-white/10 text-indigo-200 px-3 py-1 rounded-full uppercase tracking-wider">
            About SkillBridge AI
          </span>
          <h1 className="text-3xl font-bold tracking-tight text-white">
            Bridging Academic Curricula & Modern Industry Demands
          </h1>
          <p className="text-sm text-indigo-100 leading-relaxed">
            SkillBridge is an autonomous career navigation and skill-gap intelligence platform engineered to turn abstract degree requirements into actionable, milestone-driven technical readiness.
          </p>

          {onNavigate && (
            <div className="pt-2">
              <button
                onClick={() => onNavigate("assessment")}
                className="px-5 py-2.5 rounded-xl bg-white text-indigo-900 text-xs font-bold shadow-md hover:bg-indigo-50 transition-colors"
              >
                Take the 15-Min Technical Assessment →
              </button>
            </div>
          )}
        </div>
      </div>

      {/* The Problem & The Solution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-3">
          <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold text-base">
            ⚠️
          </div>
          <h2 className="text-base font-bold text-slate-900">The Problem</h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            University syllabi lag 3 to 5 years behind rapid technological shifts. Crucial competencies—such as distributed streaming with Kafka, cloud-native deployments with Kubernetes, GenAI agent architectures, and semiconductor verification—are often omitted or taught superficially.
          </p>
          <p className="text-xs text-slate-600 leading-relaxed">
            Consequently, students graduate with high GPAs but face immediate rejection during hiring because they lack practical evidence and hands-on skill proof.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-base">
            ⚡
          </div>
          <h2 className="text-base font-bold text-slate-900">The SkillBridge Solution</h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            SkillBridge establishes continuous, data-driven alignment. By indexing real-world hiring criteria and benchmark skill targets, we compute personalized skill-gap matrices and deliver focused learning roadmaps with project-based milestones.
          </p>
          <p className="text-xs text-slate-600 leading-relaxed">
            Students shift from passive memorization to verifiable proficiency, creating authentic portfolios that recruiters can trust.
          </p>
        </div>
      </div>

      {/* Stakeholder Value Grid */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <h2 className="text-xl font-bold text-slate-900">
            Who Benefits from SkillBridge?
          </h2>
          <p className="text-xs text-slate-500">
            A three-way ecosystem connecting students, educational institutions, and recruiters
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* For Students */}
          <div className="p-5 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
            <span className="text-lg">🎓</span>
            <h3 className="text-sm font-bold text-slate-900">For Students</h3>
            <ul className="text-xs text-slate-600 space-y-1.5 list-disc list-inside">
              <li>Objective technical assessments across 9 core disciplines.</li>
              <li>Clear visibility into High, Medium, and Low priority skill gaps.</li>
              <li>Week-by-week learning roadmap with curating resources.</li>
              <li>Portfolio projects with GitHub and deployment evidence.</li>
            </ul>
          </div>

          {/* For Institutions */}
          <div className="p-5 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
            <span className="text-lg">🏛️</span>
            <h3 className="text-sm font-bold text-slate-900">For Institutions</h3>
            <ul className="text-xs text-slate-600 space-y-1.5 list-disc list-inside">
              <li>Actionable cohort-level skill readiness analytics.</li>
              <li>Empirical data on emerging gaps to align future elective courses.</li>
              <li>Improved placement conversion rates through targeted prep.</li>
              <li>Accreditation compliance data demonstrating student competency.</li>
            </ul>
          </div>

          {/* For Recruiters */}
          <div className="p-5 rounded-xl bg-slate-50 border border-slate-100 space-y-2">
            <span className="text-lg">🏢</span>
            <h3 className="text-sm font-bold text-slate-900">For Recruiters</h3>
            <ul className="text-xs text-slate-600 space-y-1.5 list-disc list-inside">
              <li>Search candidates by verified capability rather than resume keywords.</li>
              <li>Inspect real project evidence, GitHub commits, and architecture proofs.</li>
              <li>Distinguish between self-reported and tested proficiencies.</li>
              <li>Dramatically reduced technical screening and interview cycle times.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* The 3-Tier Verification Engine */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-4">
        <h2 className="text-base font-bold text-slate-900">
          The 3-Tier Skill Verification Philosophy
        </h2>
        <p className="text-xs text-slate-500">
          To maintain hiring integrity, SkillBridge rejects single-checkbox certifications in favor of progressive tiers:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 font-bold">
              Tier 1
            </span>
            <h4 className="text-xs font-bold text-slate-800 pt-1">Self-Reported Rating</h4>
            <p className="text-xs text-slate-500">
              Student estimates rated during onboarding. Used exclusively as an initial baseline and marked clearly across all interfaces.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-sky-200 bg-sky-50/50 space-y-1">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-100 text-sky-700 font-bold">
              Tier 2
            </span>
            <h4 className="text-xs font-bold text-sky-950 pt-1">Assessed Proficiency</h4>
            <p className="text-xs text-sky-800">
              Validated through the timed 15-Minute Technical Assessment across practical conceptual and coding scenarios.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 space-y-1">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-bold">
              Tier 3
            </span>
            <h4 className="text-xs font-bold text-emerald-950 pt-1">Verified Credential</h4>
            <p className="text-xs text-emerald-800">
              Accompanied by verifiable code repositories, deployment links, and external recruiter/mentor sign-off.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
