import { useEffect, useState, type ReactNode } from "react";

interface SplashScreenProps {
  children: ReactNode;
}

export default function SplashScreen({ children }: SplashScreenProps) {
  const [showSplash, setShowSplash] = useState(() => {
    // Check if reduced motion is preferred
    if (typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      return false;
    }
    // Check if already displayed in this browser session
    try {
      const seen = sessionStorage.getItem("skillbridge_splash_shown");
      if (seen) return false;
    } catch {
      /* ignore */
    }
    return true;
  });

  const [fadingOut, setFadingOut] = useState(false);

  useEffect(() => {
    if (!showSplash) return;

    try {
      sessionStorage.setItem("skillbridge_splash_shown", "1");
    } catch {
      /* ignore */
    }

    // Begin fade-out at 1300ms, completely remove at 1700ms
    const fadeTimer = setTimeout(() => {
      setFadingOut(true);
    }, 1300);

    const removeTimer = setTimeout(() => {
      setShowSplash(false);
    }, 1700);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, [showSplash]);

  if (!showSplash) {
    return <>{children}</>;
  }

  return (
    <>
      <div
        className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 transition-opacity duration-400 ease-out select-none ${
          fadingOut ? "opacity-0 pointer-events-none" : "opacity-100"
        }`}
        style={{ willChange: "opacity" }}
        role="presentation"
        aria-hidden="true"
      >
        {/* Ambient glow background */}
        <div className="absolute w-72 h-72 rounded-full bg-indigo-600/20 blur-3xl pointer-events-none animate-pulse" />

        {/* Central Logo Container with smooth scale & glow */}
        <div className="relative flex flex-col items-center text-center">
          <div className="relative mb-5 group">
            {/* Soft radiant aura */}
            <div className="absolute -inset-2 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-2xl blur-lg opacity-60 animate-pulse" />

            {/* Existing SkillBridge Icon style */}
            <div className="relative w-16 h-16 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-2xl border border-indigo-400/30 transform transition-transform duration-700 ease-out hover:scale-105">
              <span className="text-white text-3xl font-bold tracking-tight font-display">S</span>
              <span className="absolute -bottom-1 -right-1 text-[9px] text-white bg-violet-600 px-1.5 py-0.5 rounded-full font-mono font-bold shadow">
                AI
              </span>
            </div>
          </div>

          {/* SkillBridge brand name */}
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-1.5">
            SkillBridge
          </h1>
          <p className="text-xs text-indigo-300 font-medium tracking-wider uppercase mt-1">
            Career & Skill Navigator
          </p>

          {/* Loading indicator bar */}
          <div className="w-28 h-1 bg-slate-800 rounded-full mt-6 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-indigo-500 to-violet-400 rounded-full animate-[progress_1.3s_ease-in-out_infinite]" />
          </div>
        </div>

        {/* Skip button for convenience */}
        <button
          onClick={() => setShowSplash(false)}
          className="absolute bottom-6 text-[11px] text-slate-500 hover:text-slate-300 transition-colors"
        >
          Skip animation →
        </button>
      </div>

      {/* Render children in background so layout is warm and ready */}
      <div className={showSplash ? "invisible" : ""}>{children}</div>
    </>
  );
}
