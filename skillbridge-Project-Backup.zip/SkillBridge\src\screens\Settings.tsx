import { useState } from "react";
import { useStore } from "../lib/store";
import { getStoredTheme, applyTheme, type ThemeMode } from "../lib/theme";
import { getStoredLanguage, setStoredLanguage, t, type Language } from "../lib/i18n";

interface SettingsProps {
  onNavigate?: (screen: string) => void;
  onOpenSignOut: () => void;
}

export default function Settings({ onNavigate, onOpenSignOut }: SettingsProps) {
  const { state, patch, reset } = useStore();

  // Form states
  const [name, setName] = useState(state.account?.name ?? "");
  const [email, setEmail] = useState(state.account?.email ?? "");
  const [college, setCollege] = useState(state.academic.college);
  const [degree, setDegree] = useState(state.academic.degree);
  const [year, setYear] = useState(state.academic.year);
  const [gradYear, setGradYear] = useState(state.academic.gradYear);
  const [cgpa, setCgpa] = useState(state.academic.cgpa);
  const [weeklyHours, setWeeklyHours] = useState(state.position.weeklyHours);

  // Preference states
  const [theme, setTheme] = useState<ThemeMode>(getStoredTheme);
  const [language, setLanguage] = useState<Language>(getStoredLanguage);

  // Notification toggles
  const [notifDigest, setNotifDigest] = useState(state.settings?.notifications.weeklyDigest ?? true);
  const [notifReminders, setNotifReminders] = useState(state.settings?.notifications.roadmapReminders ?? true);
  const [notifAlerts, setNotifAlerts] = useState(state.settings?.notifications.opportunityAlerts ?? true);

  // Privacy toggles
  const [visibility, setVisibility] = useState<"public" | "anonymous" | "private">(
    state.settings?.privacy.visibility ?? "public"
  );
  const [recruiterMessages, setRecruiterMessages] = useState(
    state.settings?.privacy.recruiterMessages ?? true
  );
  const [shareBenchmarks, setShareBenchmarks] = useState(
    state.settings?.privacy.shareBenchmarks ?? true
  );

  const [savedMessage, setSavedMessage] = useState(false);

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();

    patch({
      account: { name: name.trim(), email: email.trim() },
      academic: { ...state.academic, college, degree, year, gradYear, cgpa },
      position: { ...state.position, weeklyHours: Number(weeklyHours) || 6 },
      settings: {
        notifications: {
          weeklyDigest: notifDigest,
          roadmapReminders: notifReminders,
          opportunityAlerts: notifAlerts,
        },
        privacy: {
          visibility,
          recruiterMessages,
          shareBenchmarks,
        },
      },
    });

    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 3000);
  };

  const handleThemeChange = (newTheme: ThemeMode) => {
    setTheme(newTheme);
    applyTheme(newTheme);
    patch({ theme: newTheme });
  };

  const handleLanguageChange = (newLang: Language) => {
    setLanguage(newLang);
    setStoredLanguage(newLang);
    patch({ language: newLang });
    window.dispatchEvent(new Event("skillbridge:lang_change"));
  };

  return (
    <div className="p-5 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Settings & Preferences
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Manage your personal credentials, study habits, theme appearance, and privacy controls.
          </p>
        </div>

        {savedMessage && (
          <span className="text-xs bg-emerald-100 text-emerald-800 px-3 py-1.5 rounded-xl font-semibold animate-in fade-in">
            ✓ Settings saved successfully
          </span>
        )}
      </div>

      <form onSubmit={handleSaveAll} className="space-y-6">
        {/* 1. Account Settings */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">Account & Profile</h2>
            <p className="text-xs text-slate-500">Your public identity and contact details</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
                required
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
                required
              />
            </div>
          </div>
        </div>

        {/* 2. Academic Details */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">Academic Background</h2>
            <p className="text-xs text-slate-500">
              Used to match you with appropriate campus opportunities and recruiter filters
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">College / University</label>
              <input
                type="text"
                value={college}
                onChange={(e) => setCollege(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Degree & Branch</label>
              <input
                type="text"
                value={degree}
                onChange={(e) => setDegree(e.target.value)}
                placeholder="e.g. B.Tech Computer Science"
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Current Academic Year</label>
              <select
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
              >
                {["1st", "2nd", "3rd", "4th", "Postgraduate"].map((y) => (
                  <option key={y} value={y}>
                    {y} Year
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Graduation Year</label>
              <input
                type="number"
                value={gradYear}
                onChange={(e) => setGradYear(e.target.value)}
                placeholder="2027"
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">CGPA (0 - 10, Optional)</label>
              <input
                type="text"
                value={cgpa}
                onChange={(e) => setCgpa(e.target.value)}
                placeholder="8.5"
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Weekly Study Hours</label>
              <input
                type="number"
                min={1}
                max={40}
                value={weeklyHours}
                onChange={(e) => setWeeklyHours(Number(e.target.value))}
                className="w-full text-xs border border-slate-200 rounded-xl px-3 py-2 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
              />
            </div>
          </div>
        </div>

        {/* 3. Appearance & Language Preferences */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">Application Preferences</h2>
            <p className="text-xs text-slate-500">Customize the visual theme and language</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Theme Selector */}
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-2">
                Appearance Theme
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(["light", "dark", "system"] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => handleThemeChange(m)}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold capitalize transition-all ${
                      theme === m
                        ? "border-indigo-600 bg-indigo-50 text-indigo-700 shadow-xs"
                        : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                    }`}
                  >
                    {m === "system" ? "System Default" : `${m} Mode`}
                  </button>
                ))}
              </div>
            </div>

            {/* Language Selector */}
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-2">
                Interface Language
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleLanguageChange("en")}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-all ${
                    language === "en"
                      ? "border-indigo-600 bg-indigo-50 text-indigo-700 shadow-xs"
                      : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                  }`}
                >
                  English
                </button>
                <button
                  type="button"
                  onClick={() => handleLanguageChange("hi")}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-all ${
                    language === "hi"
                      ? "border-indigo-600 bg-indigo-50 text-indigo-700 shadow-xs"
                      : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                  }`}
                >
                  हिन्दी (Hindi)
                </button>
              </div>
            </div>
          </div>

          {/* Notifications */}
          <div className="pt-4 border-t border-slate-100 space-y-3">
            <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
              Notification Preferences
            </h3>

            <div className="space-y-2 text-xs">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifDigest}
                  onChange={(e) => setNotifDigest(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-400"
                />
                <span className="text-slate-700">Receive weekly learning digest and readiness summaries</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifReminders}
                  onChange={(e) => setNotifReminders(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-400"
                />
                <span className="text-slate-700">Roadmap task milestone notifications</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifAlerts}
                  onChange={(e) => setNotifAlerts(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-400"
                />
                <span className="text-slate-700">Alerts when new matching internship/job roles are posted</span>
              </label>
            </div>
          </div>
        </div>

        {/* 4. Privacy Settings */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">Privacy & Visibility</h2>
            <p className="text-xs text-slate-500">Control who can discover your candidate profile</p>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="font-semibold text-slate-700 block mb-1.5">Profile Visibility</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {[
                  { id: "public", label: "Public to Recruiters", desc: "Visible with name & college" },
                  { id: "anonymous", label: "Anonymous Candidate", desc: "Skills visible, identity hidden" },
                  { id: "private", label: "Private Only", desc: "Hidden from industry searches" },
                ].map((v) => (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => setVisibility(v.id as any)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      visibility === v.id
                        ? "border-indigo-600 bg-indigo-50/70 text-indigo-950 font-medium"
                        : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                    }`}
                  >
                    <p className="font-bold text-xs">{v.label}</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">{v.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-2">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={recruiterMessages}
                  onChange={(e) => setRecruiterMessages(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-400"
                />
                <span className="text-slate-700">Allow verified recruiters to message directly regarding opportunities</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={shareBenchmarks}
                  onChange={(e) => setShareBenchmarks(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-400"
                />
                <span className="text-slate-700">Include anonymized assessment metrics in cohort benchmarking</span>
              </label>
            </div>
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          {onNavigate && (
            <button
              type="button"
              onClick={() => onNavigate("overview")}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
          )}
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            Save Changes
          </button>
        </div>
      </form>

      {/* 5. Account Actions (Reset & Sign Out) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="pb-2 border-b border-slate-100">
          <h2 className="text-base font-bold text-rose-700">Danger Zone</h2>
          <p className="text-xs text-slate-500">Sign out or clear local data cache</p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div>
            <p className="font-semibold text-slate-800">Sign Out of Current Session</p>
            <p className="text-slate-500">Leaves your data saved in this browser and returns to the login screen.</p>
          </div>
          <button
            type="button"
            onClick={onOpenSignOut}
            className="w-full sm:w-auto px-4 py-2 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 font-semibold transition-colors shrink-0"
          >
            Sign Out
          </button>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs pt-3 border-t border-slate-100">
          <div>
            <p className="font-semibold text-slate-800">Clear All Local Data</p>
            <p className="text-slate-500">Permanently deletes all saved profiles, assessments, and roadmap history from this browser.</p>
          </div>
          <button
            type="button"
            onClick={() => {
              if (confirm("Are you sure you want to completely erase all SkillBridge data from this browser?")) {
                reset();
              }
            }}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold shadow-xs transition-colors shrink-0"
          >
            Reset All Data
          </button>
        </div>
      </div>
    </div>
  );
}
