import { useStore } from "../lib/store";

interface SignOutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmSignOut: () => void;
}

export default function SignOutModal({
  isOpen,
  onClose,
  onConfirmSignOut,
}: SignOutModalProps) {
  const { state } = useStore();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-slate-200 p-6 max-w-sm w-full shadow-2xl space-y-4">
        <div className="w-10 h-10 rounded-full bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
          <svg className="w-5 h-5" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M6 2H3a1 1 0 00-1 1v10a1 1 0 001 1h3M10 11l3-3-3-3M13 8H6" />
          </svg>
        </div>

        <div>
          <h3 className="text-base font-bold text-slate-900">
            Sign Out of SkillBridge?
          </h3>
          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
            Your profile, completed assessments, and roadmap progress will remain safely saved in this browser. You can sign back in at any time with your email:
            <span className="font-semibold text-slate-700 block mt-1">
              {state.account?.email ?? "your email address"}
            </span>
          </p>
        </div>

        <div className="flex items-center justify-end gap-2.5 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              onClose();
              onConfirmSignOut();
            }}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
