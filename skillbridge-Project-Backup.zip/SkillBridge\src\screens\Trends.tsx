import { TREND_SOURCES } from "../lib/catalog";

export default function Trends() {
  return (
    <div className="p-5 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-800">Industry Trends</h1>
        <p className="text-sm text-slate-500 mt-0.5">Research-based context from published reports. SkillBridge only shows figures that were checked against the source; nothing here is estimated or invented.</p>
      </div>

      <div className="space-y-3">
        {TREND_SOURCES.map((s) => (
          <div key={s.id} className="bg-white rounded-2xl border border-slate-200 p-5">
            <div className="flex items-start justify-between gap-3 flex-wrap mb-1">
              <div>
                <p className="text-sm font-semibold text-slate-800">{s.title}</p>
                <p className="text-xs text-slate-500">{s.publisher} · {s.topic}</p>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${s.published ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                {s.published ? `Published ${s.published}` : "Publication date not yet confirmed"}
              </span>
            </div>
            {s.findings.length > 0 ? (
              <ul className="space-y-1.5 mt-3">
                {s.findings.map((f) => <li key={f} className="text-sm text-slate-700 flex gap-2"><span className="text-indigo-400">•</span>{f}</li>)}
              </ul>
            ) : (
              <p className="text-xs text-slate-500 bg-slate-50 rounded-xl p-3 mt-3">Key findings not added yet. They will appear here once checked against the published report.</p>
            )}
            {s.url ? (
              <a href={s.url} target="_blank" rel="noopener noreferrer" className="inline-block text-xs text-indigo-600 hover:underline font-medium mt-3">Read the source ↗</a>
            ) : (
              <p className="text-[11px] text-slate-400 mt-3">Source link not yet verified.</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
