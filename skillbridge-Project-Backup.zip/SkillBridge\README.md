# SkillBridge — AI Career & Technical Skill Navigator

SkillBridge is an autonomous career navigation and technical skill benchmarking platform engineered to align student proficiencies with current tech industry expectations.

It bridges the gap between academic curricula and real-world hiring standards through objective multi-domain assessments, weighted skill-gap analytics, and personalized milestone-driven learning roadmaps.

---

## Key Features

1. **Startup Logo Splash Screen:** Smooth Instagram-style logo pulse and radiant glow animation on session entry.
2. **Student Performance Dashboard:** Codility-inspired analytics with a Gaussian normal distribution bell curve, 4-metric readiness strip, notification stream, featured quick-action cards, and candidate screening results.
3. **15-Minute Comprehensive Technical Assessment:**
   * 30 conceptual, practical, and scenario-based questions across 9 engineering domains.
   * Real-time 15-minute countdown timer with automatic submission upon timeout.
   * Question navigation palette (1–30), "Mark for Review" flagging, and answered/unanswered counters.
   * Live evaluation widget featuring dual semicircle gauges comparing candidate performance against pool benchmarks.
   * Full assessment scorecard report with domain breakdowns, percentile rankings, and in-depth question review with technical explanations.
   * Evaluated results directly update the student's assessed skill levels.
4. **Authentic Official Company Logos:** High-resolution transparent vector logos for top technology firms including NVIDIA, Google, Microsoft, Amazon, Qualcomm, Adobe, Intel, OpenAI, Salesforce, and Cisco.
5. **Skill Gap Analyzer:** Weighted requirement calculations classifying gaps into High, Medium, and Low severity tiers.
6. **Dynamic Learning Roadmap:** Phase-by-phase task roadmaps automatically scaled to the student's target role and self-reported weekly study hours.
7. **Projects & 3-Tier Verification:** Strict distinction between *Self-Reported*, *Assessed*, and *Verified* skills with project code evidence tracking.
8. **Appearance System:** Full Dark Mode, Light Mode, and System Default support with WCAG 2.2 AA compliant contrast ratios.
9. **Centralized Language Selection:** Full interface support for English and हिन्दी (Hindi).
10. **Integrated Help & Documentation:** In-app Instructions manual, searchable FAQ knowledge base, Learn More narrative, and a functional Sign Out workflow with data preservation.

---

## Tech Stack

* **Frontend:** React 19, TypeScript 5.7
* **Build Tooling:** Vite 8, Rolldown
* **Styling:** Tailwind CSS v4 (`@tailwindcss/vite`), CSS Variables
* **Charts & Visualizations:** Recharts, Custom SVGs
* **State Management:** React Context + LocalStorage persistence

---

## Prerequisites

* **Node.js:** v20.0.0 or higher (v24 LTS recommended)
* **npm:** v10.0.0 or higher

Check your installed versions:
```bash
node -v
npm -v
```

---

## Installation & Setup

1. **Clone or extract the repository:**
   ```bash
   cd SkillBridge
   ```

2. **Install dependencies:**
   ```bash
   npm install --legacy-peer-deps
   ```

3. **Configure environment variables (Optional):**
   ```bash
   cp .env.example .env
   ```
   *(Defaults to port `8443` on `0.0.0.0`)*

4. **Start the local development server:**
   ```bash
   npm run dev
   ```

5. **Open in your browser:**
   Navigate to [http://localhost:8443](http://localhost:8443)

   *If port 8443 is busy, run with a custom port:*
   * **PowerShell:** `$env:PORT=3000; npm run dev`
   * **Bash:** `PORT=3000 npm run dev`

---

## Production Build

To create an optimized production build:
```bash
npm run build
```

To locally preview the production build:
```bash
npm run preview
```

---

## Project Structure

```text
SkillBridge/
├── .env.example                 # Template environment variables
├── .figma/                      # Figma Make preview and kit configurations
├── index.html                   # HTML entry point shell
├── package.json                 # Project dependencies & npm scripts
├── tsconfig.json                # TypeScript compiler configuration
├── vite.config.ts               # Vite build & plugin setup
├── README.md                    # Installation and architectural documentation
├── RUN.md                       # Quick run instructions
└── src/
    ├── main.tsx                 # React DOM mount & early theme initializer
    ├── App.tsx                  # Root layout shell, routing, header, and modals
    ├── index.css                # Global Tailwind CSS v4 & WCAG contrast styles
    ├── components/
    │   ├── CompanyLogo.tsx      # Vector SVGs for official company marks
    │   ├── ProgressBar.tsx      # High-contrast 4-tier progress indicator
    │   ├── ProfileMenu.tsx      # Avatar dropdown panel (Settings, Theme, Lang, SignOut)
    │   ├── SignOutModal.tsx     # Confirmation dialog with session clearing
    │   └── SplashScreen.tsx     # Startup Instagram-style logo animation
    ├── lib/
    │   ├── assessmentData.ts    # 30-question bank across 9 engineering domains
    │   ├── catalog.ts           # Career targets, competencies, resources, companies
    │   ├── i18n.ts              # Centralized translations (English & Hindi)
    │   ├── progressColors.ts    # 4-tier color system (Red, Blue, Yellow, Green)
    │   ├── roadmap.ts           # Algorithm generating phase-by-phase learning paths
    │   ├── skillGap.ts          # Matrix comparing student capabilities vs role targets
    │   ├── store.tsx            # Global state context with LocalStorage sync
    │   └── theme.ts             # Theme manager (Dark / Light / System)
    └── screens/
        ├── Career.tsx           # Role explorer & target requirement breakdown
        ├── Companies.tsx        # Company directory with official brand logos
        ├── ComprehensiveAssessment.tsx # 15-minute timed technical screening
        ├── Dashboard.tsx        # Student performance dashboard & bell curve
        ├── Help.tsx             # Searchable FAQs & in-app feedback
        ├── IndustryPortal.tsx   # Recruiter / company candidate search view
        ├── Instructions.tsx     # Step-by-step user manual & guidelines
        ├── LearnMore.tsx        # Platform mission & 3-tier verification model
        ├── MySkills.tsx         # Skill inventory (Self-reported, Assessed, Verified)
        ├── Onboarding.tsx       # 8-step baseline diagnostic & profile wizard
        ├── Opportunities.tsx    # Internship & job matching board
        ├── Progress.tsx         # Timeline metrics, readiness history, achievements
        ├── Projects.tsx         # Portfolio project manager with GitHub/demo links
        ├── Roadmap.tsx          # Weekly milestones & task checklist
        ├── Settings.tsx         # Account, academic, notifications & privacy controls
        ├── Technologies.tsx     # Technical ecosystem & stack directory
        └── Trends.tsx           # Industry skilling trends & market research
```

---

## License

This project is private and proprietary. All company trademarks and logos (NVIDIA, Google, Microsoft, Amazon, Qualcomm, Adobe, Intel, OpenAI, Salesforce, Cisco) are property of their respective owners and used solely for educational demonstration purposes.
