import { useState, useMemo } from "react";

interface HelpProps {
  onNavigate?: (screen: string) => void;
}

interface FAQItem {
  id: string;
  category: "all" | "assessment" | "gap" | "roadmap" | "account";
  question: string;
  answer: string;
}

const FAQS: FAQItem[] = [
  {
    id: "faq_1",
    category: "assessment",
    question: "How does the 15-Minute Comprehensive Assessment differ from the Onboarding Diagnostic?",
    answer: "The Onboarding Diagnostic is a short 5-question test to establish initial baseline estimates. The 15-Minute Comprehensive Assessment is a timed 30-question test evaluating 9 engineering domains with multiple difficulty tiers. Its results directly update your assessed skill levels across the system.",
  },
  {
    id: "faq_2",
    category: "assessment",
    question: "What happens if the 15-minute timer runs out?",
    answer: "The assessment automatically submits all questions answered up to that point. Unanswered questions are scored as unanswered, and you immediately receive your scorecard and domain breakdown.",
  },
  {
    id: "faq_3",
    category: "assessment",
    question: "Can I retake the assessment?",
    answer: "Yes. You can take the assessment as often as you want to measure your progress. Every completed attempt is logged in your assessment history so you can track improvements over time.",
  },
  {
    id: "faq_4",
    category: "gap",
    question: "How are skill gap severities (High, Medium, Low) calculated?",
    answer: "Gaps are calculated by comparing your current skill level against the expected proficiency required for your target role. Skills weighted heavily by industry with a gap of 25+ points are classified as High severity and placed into Phase 1 of your roadmap.",
  },
  {
    id: "faq_5",
    category: "gap",
    question: "What is the difference between Self-Reported, Assessed, and Verified skills?",
    answer: "Self-Reported skills are your own initial estimates. Assessed skills are validated through SkillBridge's timed technical assessments. Verified skills require concrete project evidence (working GitHub repo and live demo) reviewed by an external mentor or recruiter.",
  },
  {
    id: "faq_6",
    category: "roadmap",
    question: "How is the roadmap timeline estimated?",
    answer: "The total estimated weeks are computed from the total hours needed across all identified gap tasks divided by your self-reported weekly study hours. You can adjust your weekly study hours anytime in Settings.",
  },
  {
    id: "faq_7",
    category: "account",
    question: "Where is my data stored? Will I lose it if I close the browser?",
    answer: "SkillBridge persists all state (profile, completed tasks, projects, and assessment scores) directly in your browser's local storage. As long as you don't clear your browser storage or click 'Reset All Data', your progress is retained.",
  },
  {
    id: "faq_8",
    category: "account",
    question: "How does Signing Out work in this local version?",
    answer: "Signing out ends your active session and redirects to the Welcome screen while keeping your saved data intact. You can log right back in with your registered email without losing your progress.",
  },
];

export default function Help({ onNavigate }: HelpProps) {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [expandedId, setExpandedId] = useState<string | null>("faq_1");
  const [feedback, setFeedback] = useState("");
  const [feedbackSent, setFeedbackSent] = useState(false);

  const filteredFaqs = useMemo(() => {
    return FAQS.filter((faq) => {
      const matchesCategory = selectedCategory === "all" || faq.category === selectedCategory;
      const matchesSearch =
        faq.question.toLowerCase().includes(search.toLowerCase()) ||
        faq.answer.toLowerCase().includes(search.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [search, selectedCategory]);

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedback.trim()) return;
    setFeedbackSent(true);
    setFeedback("");
    setTimeout(() => setFeedbackSent(false), 4000);
  };

  return (
    <div className="p-5 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Help & Support Center
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Answers to common questions regarding assessments, roadmap pacing, and account management.
          </p>
        </div>

        {onNavigate && (
          <button
            onClick={() => onNavigate("overview")}
            className="self-start sm:self-auto text-xs text-slate-500 hover:text-slate-800 border border-slate-200 px-3 py-1.5 rounded-lg font-medium transition-colors"
          >
            ← Back to Dashboard
          </button>
        )}
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="relative">
          <input
            type="text"
            placeholder="Search FAQs by keyword (e.g. assessment, timer, roadmap, verified)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full text-xs border border-slate-200 rounded-xl pl-9 pr-4 py-2.5 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-slate-50"
          />
          <span className="absolute left-3 top-2.5 text-slate-400 text-sm">🔍</span>
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 text-xs"
            >
              ✕
            </button>
          )}
        </div>

        <div className="flex gap-2 flex-wrap">
          {[
            { id: "all", label: "All Topics" },
            { id: "assessment", label: "Assessments" },
            { id: "gap", label: "Skill Gaps" },
            { id: "roadmap", label: "Roadmaps" },
            { id: "account", label: "Account & Storage" },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all ${
                selectedCategory === cat.id
                  ? "bg-indigo-600 text-white font-semibold shadow-xs"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* FAQs Accordion */}
      <div className="space-y-3">
        {filteredFaqs.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-xs text-slate-500">
            No matching questions found for &quot;{search}&quot;. Try adjusting your search query.
          </div>
        ) : (
          filteredFaqs.map((faq) => {
            const isOpen = expandedId === faq.id;
            return (
              <div
                key={faq.id}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs transition-all"
              >
                <button
                  type="button"
                  onClick={() => setExpandedId(isOpen ? null : faq.id)}
                  className="w-full p-4 text-left flex items-center justify-between gap-3 text-xs font-semibold text-slate-800 hover:bg-slate-50"
                >
                  <span>{faq.question}</span>
                  <span className="text-slate-400 text-sm font-mono shrink-0">
                    {isOpen ? "−" : "+"}
                  </span>
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-3 bg-slate-50/50">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* In-App Feedback / Inquiries */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">Have a Question or Feedback?</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Submit questions or bug reports directly inside the application.
          </p>
        </div>

        {feedbackSent ? (
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold animate-in fade-in">
            ✓ Thank you! Your feedback has been recorded locally.
          </div>
        ) : (
          <form onSubmit={handleFeedbackSubmit} className="space-y-3">
            <textarea
              rows={3}
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Describe what you need help with or any issues you encountered..."
              className="w-full text-xs border border-slate-200 rounded-xl p-3 text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
              required
            />
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              Submit In-App Note
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
