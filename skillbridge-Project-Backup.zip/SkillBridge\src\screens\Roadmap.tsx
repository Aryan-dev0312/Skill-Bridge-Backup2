import { useState } from "react";
import { useStore } from "../lib/store";
import { getProgressTier } from "../lib/progressColors";

const typeColors: Record<string, string> = {
  Learn: "bg-indigo-100 text-indigo-700",
  Practice: "bg-sky-100 text-sky-700",
  Project: "bg-emerald-100 text-emerald-700",
  "Mock Assessment": "bg-orange-100 text-orange-700",
};

export default function Roadmap() {
  const { state, career, roadmap, taskStats, toggleTask } = useStore();
  const firstOpen = roadmap.phases.find((p) => p.tasks.some((t) => !state.completedTasks[t.id]))?.phase ?? 1;
  const [expanded, setExpanded] = useState<number | null>(null);
  const open = expanded === null ? firstOpen : expanded;

  const finish = new Date();
  finish.setDate(finish.getDate() + roadmap.totalWeeks * 7);

  return (
    <div className="p-5 max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <h1 className="text-xl font-semibold text-slate-800">Personalized Roadmap</h1>
          <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-medium">Generated from your gaps</span>
        </div>
        <p className="text-sm text-slate-500">
          {roadmap.totalWeeks}-week plan toward {career?.title} readiness · Generated for {state.account?.name}
        </p>
      </div>

      {/* Progress bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 mb-5 shadow-xs">
        <div className="flex justify-between items-center mb-2">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-slate-800">Overall Progress</span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${getProgressTier(taskStats.pct).badgeClass}`}>
              {getProgressTier(taskStats.pct).label}
            </span>
          </div>
          <span className="text-sm font-mono font-bold text-slate-800">{taskStats.pct}%</span>
        </div>
        <div className="h-3 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden mb-3 shadow-2xs">
          <div className={`h-full rounded-full transition-all duration-500 ${getProgressTier(taskStats.pct).gradientClass}`} style={{ width: `${taskStats.pct}%` }} />
        </div>
        <div className="flex justify-between text-xs text-slate-500 font-medium">
          <span>{taskStats.done} of {taskStats.total} tasks · {roadmap.totalHours} h total</span>
          <span>Est. completion: {roadmap.totalWeeks ? finish.toLocaleDateString("en", { month: "long", year: "numeric" }) : "n/a"} at {state.position.weeklyHours} h/week</span>
        </div>
      </div>

      {roadmap.phases.length === 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-sm">
          No gaps to plan for: you meet every expected proficiency for this role. Pick a different target career or add projects.
        </div>
      )}

      {/* Phase cards */}
      <div className="space-y-3">
        {roadmap.phases.map((phase) => {
          const done = phase.tasks.filter((t) => state.completedTasks[t.id]).length;
          const status = done === phase.tasks.length ? "completed" : done > 0 || phase.phase === firstOpen ? "active" : "upcoming";
          const isOpen = open === phase.phase;
          return (
            <div key={phase.phase} className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
              <button className="w-full flex items-center gap-4 p-5 text-left hover:bg-slate-50/50 transition-colors" onClick={() => setExpanded(isOpen ? 0 : phase.phase)}>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold shrink-0 ${status === "completed" ? "bg-emerald-100 text-emerald-700" : status === "active" ? "bg-indigo-100 text-indigo-700" : "bg-slate-100 text-slate-500"}`}>
                  {status === "completed" ? "✓" : phase.phase}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-semibold text-slate-800">{phase.title}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${status === "completed" ? "bg-emerald-100 text-emerald-700" : status === "active" ? "bg-indigo-100 text-indigo-700" : "bg-slate-100 text-slate-500"}`}>
                      {status === "completed" ? "Completed" : status === "active" ? "In Progress" : "Upcoming"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{phase.weeks} · ~{phase.hours} h</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-mono font-semibold text-slate-700">{done}/{phase.tasks.length}</p>
                  <p className="text-[11px] text-slate-400">tasks done</p>
                </div>
                <div className="text-slate-400">
                  <svg className={`w-4 h-4 transition-transform ${isOpen ? "rotate-180" : ""}`} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M4 6l4 4 4-4" /></svg>
                </div>
              </button>

              {isOpen && (
                <div className="px-5 pb-5 border-t border-slate-100">
                  <div className="h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden mt-4 mb-4">
                    <div className={`h-full rounded-full transition-all ${getProgressTier(Math.round((done / phase.tasks.length) * 100)).gradientClass}`} style={{ width: `${(done / phase.tasks.length) * 100}%` }} />
                  </div>
                  <div className="space-y-2">
                    {phase.tasks.map((item) => {
                      const isDone = !!state.completedTasks[item.id];
                      return (
                        <div key={item.id} className={`p-3 rounded-xl ${isDone ? "bg-emerald-50" : "bg-slate-50"}`}>
                          <div className="flex items-center gap-3">
                            <button onClick={() => toggleTask(item.id)} aria-label={isDone ? "Mark not done" : "Mark done"}
                              className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${isDone ? "bg-emerald-500 border-emerald-500" : "border-slate-300 hover:border-indigo-400"}`}>
                              {isDone && <svg viewBox="0 0 12 12" className="w-3 h-3 text-white" fill="none" stroke="currentColor" strokeWidth="2"><path d="M2 6l3 3 5-5" /></svg>}
                            </button>
                            <span className={`flex-1 text-sm ${isDone ? "text-slate-500 line-through" : "text-slate-800"}`}>{item.title}</span>
                            <span className="text-[10px] text-slate-400 font-mono shrink-0">{item.hours}h</span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${typeColors[item.kind]}`}>{item.kind}</span>
                          </div>
                          {!isDone && (
                            <div className="pl-8 mt-2 space-y-1">
                              <p className="text-[11px] text-slate-500"><span className="font-medium text-slate-600">Why:</span> {item.why}</p>
                              <p className="text-[11px] text-slate-500"><span className="font-medium text-slate-600">Done when:</span> {item.doneWhen}</p>
                              {item.resource && (
                                <a href={item.resource.url} target="_blank" rel="noopener noreferrer" className="inline-block text-[11px] text-indigo-600 hover:underline">📚 {item.resource.title} ↗</a>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
