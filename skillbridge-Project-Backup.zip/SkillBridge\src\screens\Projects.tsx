import { useState } from "react";
import { ALL_SKILLS } from "../lib/catalog";
import { useStore, type Project } from "../lib/store";

const statusConfig: Record<string, { label: string; color: string; bg: string }> = {
  completed: { label: "Completed", color: "text-emerald-700", bg: "bg-emerald-100" },
  in_progress: { label: "In Progress", color: "text-indigo-700", bg: "bg-indigo-100" },
  planned: { label: "Planned", color: "text-slate-600", bg: "bg-slate-100" },
};
const statusPill: Record<string, string> = { self: "bg-slate-100 text-slate-600", assessed: "bg-sky-100 text-sky-700", verified: "bg-emerald-100 text-emerald-700" };
const statusText: Record<string, string> = { self: "Self-reported", assessed: "Assessed", verified: "Verified" };
const inputCls = "w-full text-sm border border-slate-200 rounded-xl px-3 py-2.5 bg-white text-slate-800 outline-none focus:ring-2 focus:ring-indigo-300";
const urlOk = (u: string) => { try { const p = new URL(u); return p.protocol === "https:" || p.protocol === "http:"; } catch { return false; } };

const blank = { title: "", description: "", techStack: "", github: "", demoUrl: "", evidence: "", status: "in_progress" as Project["status"], skills: [] as string[] };

export default function Projects() {
  const { state, patch, skills } = useStore();
  const projects = state.projects;
  const [selected, setSelected] = useState<string | null>(projects[0]?.id ?? null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(blank);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const sel = projects.find((p) => p.id === selected);

  function save() {
    const e: Record<string, string> = {};
    if (form.title.trim().length < 3) e.title = "Give the project a title (3+ characters).";
    if (form.description.trim().length < 10) e.description = "Describe what you built (10+ characters).";
    if (!form.techStack.trim()) e.techStack = "List at least one technology.";
    if (form.github && !urlOk(form.github)) e.github = "Enter a full URL starting with https://";
    if (form.demoUrl && !urlOk(form.demoUrl)) e.demoUrl = "Enter a full URL starting with https://";
    if (form.skills.length === 0) e.skills = "Select at least one related skill.";
    if (form.status === "completed" && !form.evidence.trim() && !form.github) e.evidence = "Completed projects need evidence: a GitHub link or a description of proof.";
    setErrors(e);
    if (Object.keys(e).length) return;
    const proj: Project = {
      id: `p${Date.now()}`, title: form.title.trim(), description: form.description.trim(),
      techStack: form.techStack.split(",").map((t) => t.trim()).filter(Boolean), github: form.github.trim(), demoUrl: form.demoUrl.trim(),
      skills: form.skills, evidence: form.evidence.trim(), status: form.status, reviewRequested: false, createdAt: new Date().toISOString(),
    };
    patch((s) => ({ projects: [proj, ...s.projects] }));
    setSelected(proj.id); setForm(blank); setShowForm(false);
  }

  const update = (id: string, p: Partial<Project>) => patch((s) => ({ projects: s.projects.map((x) => (x.id === id ? { ...x, ...p } : x)) }));
  const verifiedCount = Object.values(skills).filter((s) => s.status === "verified").length;

  return (
    <div className="p-5 max-w-6xl mx-auto">
      <div className="mb-6 flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-semibold text-slate-800">Projects & Skill Verification</h1>
          <p className="text-sm text-slate-500 mt-0.5">Add projects with evidence. Evidence supports a skill claim but never verifies it automatically.</p>
        </div>
        <button onClick={() => setShowForm((v) => !v)} className="bg-indigo-600 text-white text-sm px-4 py-2 rounded-xl font-medium hover:bg-indigo-700 transition-colors">
          {showForm ? "Close" : "+ New Project"}
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        <div className="bg-white rounded-2xl border border-slate-200 p-4 text-center"><p className="text-2xl font-bold text-slate-800 font-mono">{projects.length}</p><p className="text-xs text-slate-500 mt-0.5">Projects</p></div>
        <div className="bg-white rounded-2xl border border-slate-200 p-4 text-center"><p className="text-2xl font-bold text-emerald-600 font-mono">{verifiedCount}</p><p className="text-xs text-slate-500 mt-0.5">Skills Verified</p></div>
        <div className="bg-white rounded-2xl border border-slate-200 p-4 text-center"><p className="text-2xl font-bold text-amber-600 font-mono">{projects.filter((p) => p.reviewRequested).length}</p><p className="text-xs text-slate-500 mt-0.5">Awaiting Review</p></div>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 mb-5 space-y-3">
          <p className="text-sm font-semibold text-slate-700">New project</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-slate-600 block mb-1">Title *</label><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />{errors.title && <p className="text-[11px] text-rose-600 mt-1">{errors.title}</p>}</div>
            <div><label className="text-xs font-medium text-slate-600 block mb-1">Status</label>
              <select className={inputCls} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Project["status"] })}>
                <option value="planned">Planned</option><option value="in_progress">In progress</option><option value="completed">Completed</option>
              </select></div>
          </div>
          <div><label className="text-xs font-medium text-slate-600 block mb-1">Description *</label><textarea rows={3} className={`${inputCls} resize-none`} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />{errors.description && <p className="text-[11px] text-rose-600 mt-1">{errors.description}</p>}</div>
          <div><label className="text-xs font-medium text-slate-600 block mb-1">Tech stack * (comma separated)</label><input className={inputCls} placeholder="Python, FastAPI, PostgreSQL" value={form.techStack} onChange={(e) => setForm({ ...form, techStack: e.target.value })} />{errors.techStack && <p className="text-[11px] text-rose-600 mt-1">{errors.techStack}</p>}</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-slate-600 block mb-1">GitHub link</label><input className={inputCls} placeholder="https://github.com/you/project" value={form.github} onChange={(e) => setForm({ ...form, github: e.target.value })} />{errors.github && <p className="text-[11px] text-rose-600 mt-1">{errors.github}</p>}</div>
            <div><label className="text-xs font-medium text-slate-600 block mb-1">Live demo</label><input className={inputCls} placeholder="https://…" value={form.demoUrl} onChange={(e) => setForm({ ...form, demoUrl: e.target.value })} />{errors.demoUrl && <p className="text-[11px] text-rose-600 mt-1">{errors.demoUrl}</p>}</div>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-600 block mb-1">Related skills * ({form.skills.length} selected)</label>
            <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-2 bg-slate-50 rounded-xl">
              {ALL_SKILLS.map((s) => {
                const on = form.skills.includes(s);
                return <button key={s} type="button" onClick={() => setForm({ ...form, skills: on ? form.skills.filter((x) => x !== s) : [...form.skills, s] })} className={`text-[11px] px-2 py-1 rounded-full ${on ? "bg-indigo-600 text-white" : "bg-white border border-slate-200 text-slate-600"}`}>{s}</button>;
              })}
            </div>
            {errors.skills && <p className="text-[11px] text-rose-600 mt-1">{errors.skills}</p>}
          </div>
          <div><label className="text-xs font-medium text-slate-600 block mb-1">Evidence (what proves this work? e.g. tests, metrics, a link to a write-up)</label><textarea rows={2} className={`${inputCls} resize-none`} value={form.evidence} onChange={(e) => setForm({ ...form, evidence: e.target.value })} />{errors.evidence && <p className="text-[11px] text-rose-600 mt-1">{errors.evidence}</p>}</div>
          <div className="flex gap-2"><button onClick={save} className="text-sm px-4 py-2 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700">Save project</button><button onClick={() => { setShowForm(false); setErrors({}); }} className="text-sm px-3 py-2 text-slate-500">Cancel</button></div>
        </div>
      )}

      {projects.length === 0 && !showForm && (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400 mb-4">
          <p className="text-3xl mb-2">📁</p><p className="text-sm">No projects yet. Add your first project with evidence.</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Project list */}
        <div className="lg:col-span-2 space-y-3">
          {projects.map((p) => {
            const cfg = statusConfig[p.status];
            return (
              <button key={p.id} onClick={() => setSelected(p.id === selected ? null : p.id)}
                className={`w-full text-left bg-white rounded-2xl border p-4 transition-all hover:shadow-sm ${selected === p.id ? "border-indigo-400 ring-2 ring-indigo-100" : "border-slate-200"}`}>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <p className="text-sm font-semibold text-slate-800">{p.title} {p.demo && <span className="text-[9px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full ml-1">DEMO DATA</span>}</p>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium shrink-0 ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed mb-3 line-clamp-2">{p.description}</p>
                <div className="flex gap-1.5 flex-wrap">
                  {p.skills.map((s) => {
                    const st = skills[s]?.status;
                    return <span key={s} className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${st ? statusPill[st] : "bg-slate-100 text-slate-500"}`}>{st === "verified" ? "✓ " : ""}{s}</span>;
                  })}
                </div>
              </button>
            );
          })}
        </div>

        {/* Detail panel */}
        <div>
          {sel ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 sticky top-4">
              <div className="flex items-center justify-between mb-4 pb-4 border-b border-slate-100">
                <p className="text-sm font-semibold text-slate-800">{sel.title}</p>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${statusConfig[sel.status].bg} ${statusConfig[sel.status].color}`}>{statusConfig[sel.status].label}</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">{sel.description}</p>
              <div className="space-y-2 text-xs text-slate-600 mb-4">
                <p>🛠 {sel.techStack.join(" · ")}</p>
                {sel.github && <p>🔗 <a className="text-indigo-600 hover:underline break-all" href={sel.github} target="_blank" rel="noopener noreferrer">{sel.github}</a></p>}
                {sel.demoUrl && <p>🌐 <a className="text-indigo-600 hover:underline break-all" href={sel.demoUrl} target="_blank" rel="noopener noreferrer">{sel.demoUrl}</a></p>}
              </div>
              <div className="mb-4">
                <p className="text-xs font-semibold text-slate-700 mb-1">Evidence</p>
                <p className="text-xs text-slate-600">{sel.evidence || "None provided yet."}</p>
              </div>
              <div className="mb-4">
                <p className="text-xs font-semibold text-slate-700 mb-2">Related skills and their status</p>
                <div className="flex flex-wrap gap-1.5">
                  {sel.skills.map((s) => { const st = skills[s]?.status; return <span key={s} className={`text-[11px] px-2 py-0.5 rounded-full ${st ? statusPill[st] : "bg-slate-100 text-slate-500"}`}>{s}: {st ? statusText[st] : "not on profile"}</span>; })}
                </div>
              </div>
              {sel.reviewRequested ? (
                <p className="text-[11px] bg-amber-50 text-amber-700 rounded-xl p-3">Review requested. Skills stay unverified until an external reviewer confirms them (reviewer flow not yet available).</p>
              ) : (
                <button onClick={() => update(sel.id, { reviewRequested: true })} disabled={!sel.evidence && !sel.github}
                  className="w-full bg-indigo-600 text-white text-sm py-2.5 rounded-xl font-medium hover:bg-indigo-700 transition-colors disabled:opacity-40">
                  Request review
                </button>
              )}
              {!sel.evidence && !sel.github && !sel.reviewRequested && <p className="text-[10px] text-slate-400 mt-1.5">Add a GitHub link or evidence to request review.</p>}
              <div className="flex gap-2 mt-2">
                {sel.status !== "completed" && <button onClick={() => update(sel.id, { status: "completed" })} className="flex-1 border border-slate-200 text-slate-700 text-xs py-2 rounded-xl font-medium hover:bg-slate-50">Mark completed</button>}
                <button onClick={() => { patch((s) => ({ projects: s.projects.filter((x) => x.id !== sel.id) })); setSelected(null); }} className="flex-1 border border-slate-200 text-rose-600 text-xs py-2 rounded-xl font-medium hover:bg-rose-50">Delete</button>
              </div>
            </div>
          ) : projects.length > 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400"><p className="text-3xl mb-2">📁</p><p className="text-sm">Select a project to view details</p></div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
