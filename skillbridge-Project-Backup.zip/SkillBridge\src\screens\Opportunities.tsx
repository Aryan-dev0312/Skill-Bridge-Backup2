import { useState } from "react";

const opportunities = [
  {
    id: 1,
    company: "Google",
    role: "Software Engineering Intern",
    type: "Internship",
    location: "Bangalore",
    duration: "3 months",
    stipend: "₹1.5L/month",
    deadline: "Dec 15, 2024",
    match: 91,
    skills: ["Python", "Data Structures", "System Design", "Algorithms"],
    missingSkills: ["Distributed Systems"],
    status: "open",
    logo: "G",
    color: "#4285F4",
  },
  {
    id: 2,
    company: "Microsoft",
    role: "ML Research Intern",
    type: "Research",
    location: "Hyderabad",
    duration: "6 months",
    stipend: "₹80K/month",
    deadline: "Jan 10, 2025",
    match: 84,
    skills: ["Python", "Machine Learning", "TensorFlow", "Research"],
    missingSkills: ["MLOps", "PyTorch"],
    status: "open",
    logo: "M",
    color: "#0078D4",
  },
  {
    id: 3,
    company: "Zomato",
    role: "Data Analyst",
    type: "Full-time",
    location: "Gurugram",
    duration: "Permanent",
    stipend: "₹12–16 LPA",
    deadline: "Nov 30, 2024",
    match: 78,
    skills: ["SQL", "Python", "Analytics", "Dashboard"],
    missingSkills: ["Tableau", "A/B Testing"],
    status: "open",
    logo: "Z",
    color: "#E23744",
  },
  {
    id: 4,
    company: "CRED",
    role: "Backend Intern",
    type: "Internship",
    location: "Bangalore",
    duration: "4 months",
    stipend: "₹60K/month",
    deadline: "Dec 1, 2024",
    match: 72,
    skills: ["Python", "APIs", "SQL", "Git"],
    missingSkills: ["FastAPI", "Redis"],
    status: "applied",
    logo: "C",
    color: "#1C1C1C",
  },
  {
    id: 5,
    company: "Razorpay",
    role: "SDE-1",
    type: "Full-time",
    location: "Bangalore",
    duration: "Permanent",
    stipend: "₹18–24 LPA",
    deadline: "Jan 31, 2025",
    match: 68,
    skills: ["Java", "System Design", "Microservices", "SQL"],
    missingSkills: ["Java (advanced)", "Kafka"],
    status: "open",
    logo: "R",
    color: "#2EB8D3",
  },
  {
    id: 6,
    company: "IIT Delhi (Lab)",
    role: "NLP Research Intern",
    type: "Academic",
    location: "On-campus",
    duration: "6 months",
    stipend: "₹20K/month",
    deadline: "Nov 20, 2024",
    match: 65,
    skills: ["Python", "NLP", "Machine Learning", "Research"],
    missingSkills: ["Transformers", "HuggingFace"],
    status: "shortlisted",
    logo: "I",
    color: "#6B21A8",
  },
];

const typeFilters = ["All", "Internship", "Full-time", "Research", "Academic"];
const statusColors: Record<string, string> = {
  open: "bg-emerald-100 text-emerald-700",
  applied: "bg-indigo-100 text-indigo-700",
  shortlisted: "bg-amber-100 text-amber-700",
};

export default function Opportunities() {
  const [typeFilter, setTypeFilter] = useState("All");
  const [minMatch, setMinMatch] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);

  const filtered = opportunities.filter(
    (o) => (typeFilter === "All" || o.type === typeFilter) && o.match >= minMatch
  );

  const selectedOpp = opportunities.find((o) => o.id === selected);

  return (
    <div className="p-5 max-w-6xl mx-auto">
      <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800">
        <strong>DEMO DATA.</strong> These sample listings are illustrative only. They are not verified live openings and no deadline, stipend or match score here is real. For real openings, use the official careers pages in Companies.
      </div>
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-800">Opportunities</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          {filtered.length} opportunities matched · sorted by AI fit score
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-5 items-center">
        <div className="flex gap-1.5 flex-wrap">
          {typeFilters.map((t) => (
            <button
              key={t}
              onClick={() => setTypeFilter(t)}
              className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all ${
                typeFilter === t
                  ? "bg-indigo-600 text-white"
                  : "bg-white border border-slate-200 text-slate-600 hover:border-indigo-300"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <span className="text-xs text-slate-500">Min match:</span>
          <select
            value={minMatch}
            onChange={(e) => setMinMatch(Number(e.target.value))}
            className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 bg-white text-slate-700 outline-none"
          >
            {[0, 60, 70, 80, 90].map((v) => (
              <option key={v} value={v}>{v > 0 ? `${v}%+` : "Any"}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* List */}
        <div className="lg:col-span-2 space-y-3">
          {filtered.map((o) => (
            <button
              key={o.id}
              onClick={() => setSelected(o.id === selected ? null : o.id)}
              className={`w-full text-left bg-white rounded-2xl border p-4 transition-all hover:shadow-sm ${
                selected === o.id ? "border-indigo-400 ring-2 ring-indigo-100" : "border-slate-200"
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold text-white shrink-0"
                  style={{ background: o.color }}
                >
                  {o.logo}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-sm font-semibold text-slate-800">{o.role}</p>
                      <p className="text-xs text-slate-500">
                        {o.company} · {o.location} · {o.stipend}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <div
                        className="text-lg font-bold font-mono"
                        style={{ color: o.match >= 85 ? "#10B981" : o.match >= 70 ? "#4F46E5" : "#F59E0B" }}
                      >
                        {o.match}%
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${statusColors[o.status]}`}>
                      {o.status.charAt(0).toUpperCase() + o.status.slice(1)}
                    </span>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
                      {o.type}
                    </span>
                    <span className="text-[10px] text-slate-400">Due {o.deadline}</span>
                  </div>
                  <div className="h-1 rounded-full bg-slate-100 mt-2 overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${o.match}%`,
                        background: o.match >= 85 ? "#10B981" : o.match >= 70 ? "#4F46E5" : "#F59E0B",
                      }}
                    />
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Detail panel */}
        <div className="lg:col-span-1">
          {selectedOpp ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 sticky top-4">
              <div className="flex items-center gap-3 mb-4 pb-4 border-b border-slate-100">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-lg font-bold text-white"
                  style={{ background: selectedOpp.color }}
                >
                  {selectedOpp.logo}
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">{selectedOpp.company}</p>
                  <p className="text-xs text-slate-500">{selectedOpp.type}</p>
                </div>
              </div>
              <p className="text-base font-semibold text-slate-800 mb-1">{selectedOpp.role}</p>
              <div className="space-y-1 text-xs text-slate-600 mb-4">
                <p>📍 {selectedOpp.location}</p>
                <p>⏱ {selectedOpp.duration}</p>
                <p>💰 {selectedOpp.stipend}</p>
                <p>📅 Deadline: {selectedOpp.deadline}</p>
              </div>

              <div className="mb-4">
                <p className="text-xs font-semibold text-slate-700 mb-2">Required Skills</p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedOpp.skills.map((s) => (
                    <span key={s} className="text-[11px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full">✓ {s}</span>
                  ))}
                  {selectedOpp.missingSkills.map((s) => (
                    <span key={s} className="text-[11px] bg-rose-50 text-rose-700 px-2 py-0.5 rounded-full">✗ {s}</span>
                  ))}
                </div>
              </div>

              <div className="mb-4 p-3 bg-indigo-50 rounded-xl">
                <p className="text-xs font-semibold text-indigo-700 mb-0.5">AI Match Score</p>
                <p className="text-2xl font-bold font-mono text-indigo-700">{selectedOpp.match}%</p>
                <p className="text-[11px] text-indigo-600 mt-0.5">
                  {selectedOpp.missingSkills.length} skill{selectedOpp.missingSkills.length !== 1 ? "s" : ""} to improve
                </p>
              </div>

              <button className="w-full bg-indigo-600 text-white text-sm py-2.5 rounded-xl font-medium hover:bg-indigo-700 transition-colors">
                {selectedOpp.status === "applied" ? "View Application" : "Apply Now"}
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400">
              <p className="text-3xl mb-2">💼</p>
              <p className="text-sm">Select an opportunity to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
