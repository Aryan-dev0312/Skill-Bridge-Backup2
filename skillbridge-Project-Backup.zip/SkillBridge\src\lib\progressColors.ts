export interface ProgressTier {
  category: "low" | "normal" | "intermediate" | "complete";
  label: string;
  gradientClass: string;
  solidColor: string;
  textColor: string;
  badgeClass: string;
}

export function getProgressTier(value: number): ProgressTier {
  if (value < 40) {
    return {
      category: "low",
      label: "Needs Focus",
      gradientClass: "bg-gradient-to-r from-rose-500 to-red-600",
      solidColor: "#E11D48",
      textColor: "text-rose-700 dark:text-rose-400",
      badgeClass: "bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-950/50 dark:border-rose-800 dark:text-rose-300",
    };
  }
  if (value < 65) {
    return {
      category: "normal",
      label: "In Progress",
      gradientClass: "bg-gradient-to-r from-blue-500 to-indigo-600",
      solidColor: "#2563EB",
      textColor: "text-blue-700 dark:text-blue-400",
      badgeClass: "bg-blue-50 border-blue-200 text-blue-700 dark:bg-blue-950/50 dark:border-blue-800 dark:text-blue-300",
    };
  }
  if (value < 85) {
    return {
      category: "intermediate",
      label: "Proficient",
      gradientClass: "bg-gradient-to-r from-amber-400 to-yellow-500",
      solidColor: "#F59E0B",
      textColor: "text-amber-800 dark:text-amber-300",
      badgeClass: "bg-amber-50 border-amber-200 text-amber-800 dark:bg-amber-950/50 dark:border-amber-800 dark:text-amber-300",
    };
  }
  return {
    category: "complete",
    label: "Mastered",
    gradientClass: "bg-gradient-to-r from-emerald-500 to-green-600",
    solidColor: "#10B981",
    textColor: "text-emerald-700 dark:text-emerald-400",
    badgeClass: "bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-950/50 dark:border-emerald-800 dark:text-emerald-300",
  };
}
